"use strict";
(() => {
  // src/facebook/urls.ts
  var FACEBOOK = "https://www.facebook.com";
  var HOSTS = /* @__PURE__ */ new Set(["facebook.com", "www.facebook.com", "web.facebook.com", "m.facebook.com"]);
  var NOT_USERNAMES = /* @__PURE__ */ new Set([
    "about",
    "ads",
    "adsmanager",
    "ajax",
    "api",
    "appcenter",
    "apps",
    "bookmarks",
    "business",
    "careers",
    "checkpoint",
    "comment",
    "commerce",
    "composer",
    "creatorstudio",
    "dialog",
    "directory",
    "donate",
    "events",
    "facebook",
    "feeds",
    "find-friends",
    "friends",
    "friendship",
    "fundraisers",
    "games",
    "gaming",
    "groups",
    "hashtag",
    "help",
    "home.php",
    "index.php",
    "instantgames",
    "jobs",
    "l.php",
    "latest",
    "legal",
    "lists",
    "live",
    "login",
    "login.php",
    "logout.php",
    "marketplace",
    "me",
    "media",
    "memories",
    "messages",
    "notes",
    "notifications",
    "offers",
    "onthisday",
    "pages",
    "payments",
    "people",
    "permalink.php",
    "photo",
    "photo.php",
    "photos",
    "places",
    "plugins",
    "pokes",
    "policies",
    "privacy",
    "profile.php",
    "recover",
    "reel",
    "reels",
    "reg",
    "rsrc.php",
    "saved",
    "search",
    "settings",
    "share",
    "share.php",
    "sharer",
    "sharer.php",
    "shops",
    "stories",
    "story.php",
    "subscriptions",
    "terms",
    "video",
    "videos",
    "watch",
    "weather"
  ]);
  var NOT_GROUPS = /* @__PURE__ */ new Set([
    "categories",
    "create",
    "discover",
    "explore",
    "feed",
    "joins",
    "notifications",
    "search",
    "your_groups"
  ]);
  var SUBPAGES = /* @__PURE__ */ new Set([
    "about",
    "buy_sell_discussion",
    "discussion",
    "e2ee",
    "events",
    "featured",
    "files",
    "followers",
    "following",
    "friends",
    "friends_all",
    "friends_mutual",
    "friends_recent",
    "list",
    "media",
    "members",
    "new",
    "people",
    "permalink",
    "photos",
    "posts",
    "reels",
    "requests",
    "suggestions",
    "t",
    "top",
    "user",
    "videos"
  ]);
  function isFacebookPathWord(part) {
    const lower = part.toLowerCase();
    return NOT_USERNAMES.has(lower) || NOT_GROUPS.has(lower) || SUBPAGES.has(lower);
  }
  var USERNAME = /^[a-z0-9.]{2,50}$/i;
  var NUMBER = /^\d{1,20}$/;
  function facebookUrl(href, base = FACEBOOK) {
    let url;
    try {
      url = new URL(href, base);
    } catch {
      return null;
    }
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    return HOSTS.has(url.hostname.toLowerCase()) ? url : null;
  }
  function pathParts(url) {
    return url.pathname.split("/").filter(Boolean).map((part) => {
      try {
        return decodeURIComponent(part);
      } catch {
        return part;
      }
    });
  }
  var byId = (id) => ({
    id,
    username: null,
    url: `${FACEBOOK}/profile.php?id=${id}`
  });
  var byUsername = (username) => ({
    id: null,
    username,
    url: `${FACEBOOK}/${username}`
  });
  function profileKey(profile) {
    return profile.id ? `id:${profile.id}` : `user:${(profile.username ?? "").toLowerCase()}`;
  }
  function profileFromUrl(url) {
    const [first, second, third, fourth] = pathParts(url);
    if (!first) return null;
    const lower = first.toLowerCase();
    if (lower === "profile.php") {
      const id = url.searchParams.get("id");
      return id && NUMBER.test(id) ? byId(id) : null;
    }
    if (lower === "friends") {
      const id = url.searchParams.get("profile_id");
      return id && NUMBER.test(id) ? byId(id) : null;
    }
    if (lower === "people" && third && NUMBER.test(third)) return byId(third);
    if (lower === "groups" && third === "user" && fourth && NUMBER.test(fourth)) return byId(fourth);
    if (NOT_USERNAMES.has(lower) || second !== void 0) return null;
    if (NUMBER.test(first)) return byId(first);
    return USERNAME.test(first) ? byUsername(first) : null;
  }
  function groupFromUrl(url) {
    const [first, second] = pathParts(url);
    if (first?.toLowerCase() !== "groups" || !second || NOT_GROUPS.has(second.toLowerCase()))
      return null;
    return { id: second, url: `${FACEBOOK}/groups/${encodeURIComponent(second)}/` };
  }
  function threadFromUrl(url) {
    const [first, second, third, fourth] = pathParts(url);
    if (first !== "messages") return null;
    if (second === "t" && third)
      return { id: third, encrypted: false, url: `${FACEBOOK}/messages/t/${third}/` };
    if (second === "e2ee" && third === "t" && fourth)
      return { id: fourth, encrypted: true, url: `${FACEBOOK}/messages/e2ee/t/${fourth}/` };
    return null;
  }
  function postUrlFrom(url) {
    const [first, second, third, fourth] = pathParts(url);
    if (!first) return null;
    const lower = first.toLowerCase();
    if (lower === "groups" && second && (third === "posts" || third === "permalink") && fourth)
      return `${FACEBOOK}/groups/${second}/posts/${fourth}/`;
    if (lower === "permalink.php" || lower === "story.php") {
      const story = url.searchParams.get("story_fbid");
      if (!story) return null;
      const owner = url.searchParams.get("id");
      return `${FACEBOOK}/${lower}?story_fbid=${encodeURIComponent(story)}${owner ? `&id=${encodeURIComponent(owner)}` : ""}`;
    }
    if (second === "posts" && third && !NOT_USERNAMES.has(lower))
      return `${FACEBOOK}/${first}/posts/${third}`;
    return null;
  }
  function tabKind(tab) {
    const t = tab.toLowerCase();
    if (t.startsWith("friends")) return "friends";
    if (t === "followers") return "followers";
    if (t === "following") return "following";
    return "profile";
  }
  function classifyUrl(href) {
    const none = { profile: null, group: null, thread: null };
    const url = facebookUrl(href);
    if (!url) return { kind: "other", ...none };
    const [first = "", second, third, fourth] = pathParts(url);
    const lower = first.toLowerCase();
    if (lower === "" || lower === "home.php") return { kind: "feed", ...none };
    if (lower === "messages") {
      const thread = threadFromUrl(url);
      return { kind: thread ? "chat" : "chats", ...none, thread };
    }
    if (lower === "groups") {
      if (!second || NOT_GROUPS.has(second.toLowerCase()))
        return { kind: second?.toLowerCase() === "search" ? "search" : "groups", ...none };
      const group = groupFromUrl(url);
      if (third === "members" || third === "people") return { kind: "group-members", ...none, group };
      if (third === "user" && fourth)
        return { kind: "profile", ...none, group, profile: profileFromUrl(url) };
      if ((third === "posts" || third === "permalink") && fourth)
        return { kind: "post", ...none, group };
      return { kind: "group", ...none, group };
    }
    if (lower === "search") return { kind: "search", ...none };
    if (lower === "friends") return { kind: "friends", ...none };
    if (lower === "notifications") return { kind: "notifications", ...none };
    if (lower === "permalink.php" || lower === "story.php") return { kind: "post", ...none };
    if (lower === "profile.php")
      return {
        kind: tabKind(url.searchParams.get("sk") ?? ""),
        ...none,
        profile: profileFromUrl(url)
      };
    if (lower === "me") return { kind: tabKind(second ?? ""), ...none };
    if (lower === "people" && third)
      return { kind: "profile", ...none, profile: profileFromUrl(url) };
    if (NOT_USERNAMES.has(lower)) return { kind: "other", ...none };
    const profile = profileFromUrl(new URL(`${FACEBOOK}/${encodeURIComponent(first)}`));
    if (!profile) return { kind: "other", ...none };
    if (second === "posts" && third) return { kind: "post", ...none, profile };
    return { kind: tabKind(second ?? ""), ...none, profile };
  }

  // src/facebook/dom.ts
  var SHOW_ELEMENT = 1;
  var SHOW_TEXT = 4;
  var BLOCKS = /* @__PURE__ */ new Set([
    "ADDRESS",
    "ARTICLE",
    "ASIDE",
    "BLOCKQUOTE",
    "BODY",
    "DD",
    "DIV",
    "DL",
    "DT",
    "FIELDSET",
    "FIGCAPTION",
    "FIGURE",
    "FOOTER",
    "FORM",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "HEADER",
    "LI",
    "MAIN",
    "NAV",
    "OL",
    "P",
    "SECTION",
    "TABLE",
    "TD",
    "TH",
    "TR",
    "UL"
  ]);
  var BLOCK_ROLES = /* @__PURE__ */ new Set(["article", "heading", "list", "listitem", "row"]);
  var UNREAD = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE"]);
  var EMOJI = /[\p{Extended_Pictographic}\p{Regional_Indicator}]/u;
  function clean(text) {
    return (text ?? "").replace(/[\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g, "").replace(/\s+/g, " ").trim();
  }
  function documentOf(root) {
    return root.nodeType === 9 ? root : root.ownerDocument;
  }
  function* elementsIn(root) {
    const walker = documentOf(root).createTreeWalker(root, SHOW_ELEMENT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) yield node;
  }
  function* elementsAfter(element, root) {
    const walker = documentOf(root).createTreeWalker(root, SHOW_ELEMENT);
    for (let e = element; e && e !== root; e = e.parentElement) {
      walker.currentNode = e;
      const next = walker.nextSibling();
      if (!next) continue;
      for (let node = next; node; node = walker.nextNode()) yield node;
      return;
    }
  }
  function isHeading(element) {
    return /^H[1-6]$/.test(element.tagName) || element.getAttribute("role") === "heading";
  }
  function unread(element, root) {
    for (let e = element; e && e !== root; e = e.parentElement)
      if (UNREAD.has(e.tagName) || e.tagName.toLowerCase() === "svg") return true;
    return false;
  }
  function excluded(element, selector, root) {
    const match = element.closest(selector);
    return match !== null && match !== root && root.contains(match);
  }
  function startsLine(element) {
    return BLOCKS.has(element.tagName) || BLOCK_ROLES.has(element.getAttribute("role") ?? "") || element.getAttribute("dir") === "auto";
  }
  function blockOf(element, root) {
    for (let e = element; e && e !== root; e = e.parentElement)
      if (startsLine(e)) return e;
    return root;
  }
  function textLines(root, max = 60, exclude) {
    const lines = [];
    let block = null;
    let current = "";
    const finish = () => {
      const line = clean(current);
      if (line && lines[lines.length - 1] !== line) lines.push(line);
      current = "";
    };
    const walker = documentOf(root).createTreeWalker(root, SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const value = node.nodeValue ?? "";
      const parent = node.parentElement;
      if (!value.trim() || !parent || unread(parent, root)) continue;
      if (exclude && excluded(parent, exclude, root)) continue;
      const here2 = blockOf(parent, root);
      if (here2 !== block) {
        finish();
        if (lines.length >= max) break;
        block = here2;
      }
      const join = current && !/\s$/.test(current) && !/^\s/.test(value) ? " " : "";
      current += join + value;
    }
    finish();
    return lines.slice(0, max);
  }
  function textWithEmoji(element) {
    let text = "";
    const walker = documentOf(element).createTreeWalker(element, SHOW_ELEMENT | SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      if (node.nodeType === 3) text += node.nodeValue ?? "";
      else if (node.tagName === "IMG") {
        const alt = node.getAttribute("alt") ?? "";
        if (EMOJI.test(alt) && !new RegExp("\\p{L}", "u").test(alt)) text += alt;
      }
    }
    return clean(text);
  }
  function textPieces(root) {
    const pieces = [];
    const walker = documentOf(root).createTreeWalker(root, SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const piece = (node.nodeValue ?? "").trim();
      if (piece) pieces.push(piece);
    }
    return pieces;
  }
  function closestWithin(element, selector, root) {
    for (let e = element; e; e = e.parentElement) {
      if (e.matches(selector)) return e;
      if (e === root) break;
    }
    return null;
  }
  function outermost(root, selector) {
    const all = [root, ...root.querySelectorAll(selector)].filter((e) => e.matches(selector));
    const matched = new Set(all);
    return all.filter((element) => {
      for (let up = element.parentElement; up && up !== root.parentElement; up = up.parentElement)
        if (matched.has(up)) return false;
      return true;
    });
  }
  function labelOf(element) {
    return clean(element.getAttribute("aria-label")) || clean(element.textContent);
  }
  function buttonLabels(root) {
    return [...root.querySelectorAll('[role="button"], button')].map(labelOf).filter(Boolean);
  }
  function inTopBar(element) {
    return element.closest('[role="banner"]') !== null;
  }
  function tabsIn(root) {
    return [...root.querySelectorAll('[role="tablist"]')].find((tabs) => !inTopBar(tabs)) ?? null;
  }
  var PRECEDING = 2;
  var FOLLOWING = 4;
  function isBefore(element, other) {
    return (other.compareDocumentPosition(element) & PRECEDING) !== 0 && !other.contains(element);
  }
  function isAfter(element, other) {
    return (other.compareDocumentPosition(element) & FOLLOWING) !== 0 && !other.contains(element);
  }
  function namesOn(anchors) {
    const texts = anchors.map((anchor) => textLines(anchor, 1)[0]);
    const labels = anchors.flatMap((anchor) => [
      anchor.getAttribute("aria-label"),
      ...[...anchor.querySelectorAll("img[alt], [aria-label]")].map(
        (e) => e.getAttribute("alt") ?? e.getAttribute("aria-label")
      )
    ]);
    return [...texts, ...labels.map(withoutPicturePrefix)].filter(
      (name) => Boolean(name)
    );
  }
  function withoutPicturePrefix(label) {
    return clean(label).replace(/^(profile (picture|photo) of|may be an image of)\s+/i, "");
  }
  function collectLinked(root, base, parse, options = {}) {
    const keyOf2 = /* @__PURE__ */ new Map();
    const found = /* @__PURE__ */ new Map();
    let section = null;
    for (const element of elementsIn(root)) {
      const title = options.sectionOf?.(element);
      if (title) {
        section = title;
        continue;
      }
      if (element.tagName !== "A") continue;
      const href = element.getAttribute("href");
      if (!href || options.skip?.(element)) continue;
      const url = facebookUrl(href, base);
      const parsed = url ? parse(url) : null;
      if (!parsed) continue;
      keyOf2.set(element, parsed.key);
      const entry = found.get(parsed.key);
      if (entry) entry.anchors.push(element);
      else found.set(parsed.key, { value: parsed.value, anchors: [element], section });
    }
    return [...found].map(([key, entry]) => ({
      key,
      value: entry.value,
      anchors: entry.anchors,
      section: entry.section,
      card: cardOf(entry.anchors[0], key, keyOf2, root)
    }));
  }
  function cardOf(anchor, key, keyOf2, root) {
    let card = anchor;
    for (let steps = 0; steps < 12 && card !== root; steps++) {
      const up = card.parentElement;
      if (!up || holdsAnother(up, key, keyOf2)) break;
      card = up;
    }
    return card;
  }
  function holdsAnother(box, key, keyOf2) {
    for (const anchor of box.querySelectorAll("a[href]")) {
      const other = keyOf2.get(anchor);
      if (other !== void 0 && other !== key) return true;
    }
    return false;
  }

  // src/facebook/vocabulary.ts
  var UI_WORDS = /* @__PURE__ */ new Set([
    "aa",
    "about",
    "accept",
    "account",
    "active now",
    "add friend",
    "add to story",
    "admin",
    "admins",
    "admins and moderators",
    "all",
    "all friends",
    "all reactions:",
    "and",
    "attach a file",
    "actions for this post",
    "audio call",
    "back",
    "birthdays",
    "block",
    "cancel",
    "cancel request",
    "chat settings",
    "chats",
    "close",
    "close chat",
    "comment",
    "comments",
    "conversation information",
    "confirm",
    "confirm request",
    "create",
    "create new group",
    "delete",
    "delete request",
    "discover",
    "discussion",
    "edit",
    "edit bio",
    "edit details",
    "edit featured",
    "edit profile",
    "education",
    "emoji",
    "enter",
    "events",
    "facebook",
    "family members",
    "featured",
    "feed",
    "files",
    "filters",
    "follow",
    "followers",
    "following",
    "friend requests",
    "friends",
    "gif",
    "group expert",
    "groups",
    "groups you’ve joined",
    "groups you've joined",
    "hide",
    "hobbies",
    "home",
    "interests",
    "intro",
    "invite",
    "join",
    "join group",
    "joined",
    "leave a comment",
    "learn more",
    "like",
    "life events",
    "links",
    "loading...",
    "loading…",
    "manage posts",
    "mark as read",
    "media",
    "member",
    "members",
    "mentions",
    "menu",
    "message",
    "messages",
    "messenger",
    "minimize chat",
    "moderator",
    "moderators",
    "more",
    "more actions",
    "most relevant",
    "mutual",
    "mutual friends",
    "new message",
    "new to the group",
    "newest",
    "notifications",
    "open in messenger",
    "overview",
    "pending admin approval",
    "people",
    "people follow this",
    "people you may know",
    "person follows this",
    "personal details",
    "photos",
    "places lived",
    "posts",
    "press enter to send",
    "private group",
    "profile",
    "public group",
    "react",
    "reels",
    "remove",
    "reply",
    "report",
    "request accepted",
    "request canceled",
    "request cancelled",
    "request declined",
    "request deleted",
    "request removed",
    "request sent",
    "respond",
    "search",
    "search messenger",
    "see all",
    "see all friends",
    "see all in messenger",
    "see all mutual friends",
    "see less",
    "see more",
    "see options",
    "send",
    "sent requests",
    "settings",
    "share",
    "sponsored",
    "start a video call",
    "start a voice call",
    "sticker",
    "suggestions",
    "thumbs up",
    "top contributor",
    "unfollow",
    "unread",
    "unread message",
    "unread message:",
    "video call",
    "videos",
    "view group",
    "view profile",
    "view sent requests",
    "visit",
    "voice clip",
    "work",
    "write a comment…",
    "write a public comment…",
    "write something…",
    "you",
    "you replied",
    "you sent",
    "your groups"
  ]);
  var WEEKDAY = "(?:mon|tue|wed|thu|fri|sat|sun)[a-z]*\\.?";
  var MONTH = "(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?";
  var CLOCK = "\\d{1,2}:\\d{2}(?:\\s?[ap]\\.?m\\.?)?";
  var AT = `(?:,?\\s(?:at\\s)?${CLOCK})?`;
  var WHEN_FORMS = [
    "just now",
    "now",
    "a few seconds ago",
    "\\d+\\s?(?:s|m|h|d|w|y|min|mins|hr|hrs|wk|wks)",
    "(?:about\\s)?(?:an?|\\d+)\\s(?:second|minute|hour|day|week|month|year)s?\\sago",
    `(?:today|yesterday|${WEEKDAY})${AT}`,
    `${MONTH}\\s\\d{1,2}(?:,?\\s\\d{4})?${AT}`,
    `\\d{1,2}\\s${MONTH}(?:\\s\\d{4})?${AT}`,
    `\\d{1,2}/\\d{1,2}/\\d{2,4}${AT}`,
    CLOCK
  ];
  var ANY_WHEN = `(?:${WHEN_FORMS.map((form) => `(?:${form})`).join("|")})`;
  var WHEN = new RegExp(`^${ANY_WHEN}$`, "i");
  function isWhen(text) {
    return WHEN.test(text.trim());
  }
  var DATE = new RegExp(
    `^(?:${MONTH}\\s\\d{1,2}(?:,?\\s\\d{4})?|\\d{1,2}\\s${MONTH}(?:\\s\\d{4})?|\\d{1,2}/\\d{1,2}/\\d{2,4})$`,
    "i"
  );
  function isDate(text) {
    return DATE.test(text.trim());
  }
  var COUNTS_AND_TIMES = [
    /^[\d.,]+\s*[km]?\s+(members?|comments?|shares?|mutual( friends?)?|friends?|(friend |sent )?requests?|followers?|following|reactions?|posts?( (a|per) (day|week))?|new posts?( today)?)$/i,
    /^followed by [\d.,]+\s*[km]?$/i,
    /^(public|private) group(\s*·\s*[\d.,]+\s*[km]?\s+members)?$/i,
    /^all reactions:?\s*[\d.,]*\s*[km]?$/i,
    /^[\d.,]+\s*[km]?\s+(people|person)\s+follows?\s+this$/i,
    /^[\d.,]+\s*[km]?\s+mutual friends?\s+including$/i,
    /^[·•|]$/,
    WHEN,
    new RegExp(`^joined\\s${ANY_WHEN}$`, "i")
  ];
  function isFacebookText(text) {
    const t = text.trim().toLowerCase();
    return UI_WORDS.has(t) || COUNTS_AND_TIMES.some((pattern) => pattern.test(t));
  }
  function isFacebookLine(line) {
    const parts = line.split(/\s*[·•|]\s*/).filter(Boolean);
    return parts.length > 0 && parts.every(isFacebookText);
  }
  var BADGE = /^(admin|moderator|group expert|top contributor|rising contributor|all-star contributor|new member|conversation starter|visual storyteller|founding member|link curator|greeter)$/i;
  var SECTION = /^(admins?\s*(?:and|&)\s*moderators?|moderators?|admins?|group experts?|members|new to the group|friends|friend requests|members with things in common|members near you|people you may know|top contributors?|group contributors|contributors|people|groups)(?:\s*[·•]\s*[\d.,]+\s*[km]?)?$/i;
  function withoutCount(text) {
    return text.replace(/\s*[·•]\s*[\d.,]+\s*[km]?$/i, "").trim();
  }
  function sectionTitleOf(text) {
    const match = SECTION.exec(text.trim());
    return match?.[1] ?? null;
  }
  function parseCount(text) {
    const match = /^([\d.,]+)\s*([km])?$/i.exec(text.trim());
    if (!match?.[1]) return null;
    const suffix = match[2]?.toLowerCase();
    const number = Number(
      suffix ? match[1].replace(/,/g, "") : match[1].replace(/[.,](?=\d{3}\b)/g, "")
    );
    if (!Number.isFinite(number)) return null;
    return Math.round(number * (suffix === "k" ? 1e3 : suffix === "m" ? 1e6 : 1));
  }

  // src/facebook/people.ts
  function isNameLike(text) {
    return text.length > 0 && text.length <= 80 && !isFacebookText(text) && !/^\d/.test(text) && !/mutual friends?|^see all|^facebook$/i.test(text);
  }
  function bestName(names) {
    return names.find(isNameLike) ?? null;
  }
  var sameName = (a, b) => clean(a).toLowerCase() === clean(b).toLowerCase();
  function peopleLinked(anchors, base) {
    const found = /* @__PURE__ */ new Map();
    for (const anchor of anchors) {
      if (inTopBar(anchor)) continue;
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const profile = url ? profileFromUrl(url) : null;
      if (!profile) continue;
      const entry = found.get(profileKey(profile));
      if (entry) entry.anchors.push(anchor);
      else found.set(profileKey(profile), { profile, anchors: [anchor] });
    }
    return [...found.values()].map(({ profile, anchors: anchors2 }) => ({
      profile,
      name: bestName(namesOn(anchors2)),
      inWords: anchors2.some((anchor) => textLines(anchor, 1).some(isNameLike))
    }));
  }
  function aboutWhom(people) {
    const first = people[0];
    if (!first) return null;
    const one = people.every(
      (person) => person === first || person.name && first.name && sameName(person.name, first.name)
    );
    if (one) return first;
    const inWords = people.filter((person) => person.inWords);
    return inWords.length === 1 ? inWords[0] : null;
  }
  function sectionStart(element) {
    const heading = isHeading(element);
    if (!heading && element.childElementCount > 0) return null;
    if (element.closest('a, [role="tab"], [role="button"], button')) return null;
    const text = clean(element.textContent);
    if (!text || text.length > 60 || !heading && BADGE.test(text)) return null;
    const known = sectionTitleOf(text);
    if (known || !heading || element.tagName === "H1" || element.querySelector("a[href]"))
      return known;
    return withoutCount(text) || null;
  }
  function badgesIn(card) {
    const badges = /* @__PURE__ */ new Set();
    for (const element of elementsIn(card)) {
      const text = clean(element.textContent);
      if (text.length <= 40 && BADGE.test(text)) badges.add(text);
    }
    return [...badges];
  }
  function readPeople(root, base, options = {}) {
    const { after } = options;
    const linked = collectLinked(
      root,
      base,
      (url) => {
        const profile = profileFromUrl(url);
        return profile ? { key: profileKey(profile), value: profile } : null;
      },
      {
        skip: (anchor) => inTopBar(anchor) || after != null && isBefore(anchor, after),
        sectionOf: options.sections ? sectionStart : void 0
      }
    );
    const people = [];
    for (const entry of linked) {
      const name = bestName(namesOn(entry.anchors));
      if (!name) continue;
      people.push({
        name,
        profile: entry.value,
        details: detailsIn(entry.card, name),
        badges: badgesIn(entry.card),
        section: entry.section,
        request: null
      });
    }
    return people;
  }
  function detailsIn(card, name, buttons = false) {
    const lines = textLines(card, 12, buttons ? void 0 : '[role="button"], button');
    return lines.slice(lines.findIndex((line) => line.startsWith(name)) + 1).filter(
      (line) => !line.startsWith(name) && !BADGE.test(line) && !UI_WORDS.has(line.toLowerCase()) && line.length <= 120
    ).slice(0, 3);
  }
  function readPeopleAnywhere(doc, main, base) {
    const places = [main, ...doc.querySelectorAll('[role="navigation"]')].filter(
      (place) => !inTopBar(place)
    );
    let best = [];
    for (const place of places) {
      const people = readPeople(place, base, { sections: true });
      if (people.length > best.length) best = people;
    }
    return best;
  }

  // src/facebook/chat.ts
  var MINE = /^you (sent|replied|forwarded|unsent|reacted)\b/i;
  var REPLIED = /^(.+?) replied to\b/i;
  var CONVERSATION = /^(?:messages in )?conversation (?:with|titled) (.+)$/i;
  var NOTICE = /^(seen( by .+)?|delivered|sending…?|.+ is typing…?|you are now connected on messenger\.?|you['’]re now friends on facebook\.?|say hi to your new facebook friend.*|messages and calls are secured with end-to-end encryption.*|.+ unsent a message)$/i;
  var NOT_SAID = 'h1, h2, h3, h4, h5, h6, [role="heading"], [role="button"], button, [role="textbox"], [contenteditable="true"]';
  function measuredSide(element, conversation) {
    const box = element.getBoundingClientRect();
    const around = conversation.getBoundingClientRect();
    if (box.width === 0 || around.width === 0) return null;
    const left = box.left - around.left;
    const right = around.right - box.right;
    if (Math.abs(left - right) < Math.max(4, around.width * 0.02)) return null;
    return left < right ? "left" : "right";
  }
  var isConversation = (element) => CONVERSATION.test(clean(element.getAttribute("aria-label")));
  function conversationIn(scope) {
    for (const element of scope.querySelectorAll("[aria-label]")) {
      if (isConversation(element)) return element;
    }
    return scope.querySelector('[role="grid"]') ?? scope;
  }
  function rowsIn(conversation) {
    for (const selector of ['[role="row"]', '[role="article"]']) {
      const rows = outermost(conversation, selector);
      if (rows.length > 0) return rows;
    }
    return outermost(conversation, '[dir="auto"]');
  }
  function pictureIn(row, message) {
    for (const image of row.querySelectorAll(
      '[aria-hidden="true"] img[alt], [aria-hidden="true"] [role="img"][aria-label]'
    )) {
      if (message.contains(image) || !isBefore(image, message)) continue;
      const name = withoutPicturePrefix(
        image.getAttribute("alt") ?? image.getAttribute("aria-label")
      );
      if (new RegExp("\\p{L}", "u").test(name) && isNameLike(name) && !NOTICE.test(name)) return name;
    }
    return null;
  }
  function repeatedBy(message, text, conversation, isRow) {
    const start = text.split("\n")[0].slice(0, 40);
    for (const element of elementsAfter(message, conversation)) {
      if (isRow.has(element)) break;
      if (element.getAttribute("role") !== "button") continue;
      const repeat = textWithEmoji(element);
      if (repeat.length > start.length && repeat.includes(start))
        return textPieces(element).includes("You") ? "me" : "them";
    }
    return null;
  }
  function isSenderLabel(text) {
    return MINE.test(text) || REPLIED.test(text);
  }
  function messageIn(row) {
    const said = outermost(row, '[dir="auto"]').filter((element) => !closestWithin(element, NOT_SAID, row)).map((element) => ({ element, text: textWithEmoji(element) })).filter(
      ({ text }) => text && !isWhen(text) && !UI_WORDS.has(text.toLowerCase()) && !NOTICE.test(text)
    );
    const words2 = said.filter(({ text }) => !isSenderLabel(text));
    const kept = words2.length > 0 ? words2 : said;
    const first = kept[0];
    return first ? { element: first.element, text: kept.map(({ text }) => text).join("\n") } : null;
  }
  function labelsIn(row, message) {
    const headings = [...row.querySelectorAll('h1, h2, h3, h4, h5, h6, [role="heading"]')].filter((element) => isBefore(element, message)).map((element) => ({ text: clean(element.textContent), heading: true }));
    const lines = textLines(row, 20).filter(isSenderLabel).map((text) => ({ text, heading: false }));
    return [...headings, ...lines].filter(({ text }) => text);
  }
  function whoWith(scope, conversation, base) {
    const outside = (element) => conversation === scope || !conversation.contains(element);
    for (const anchor of scope.querySelectorAll("a[href]")) {
      if (!outside(anchor)) continue;
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const profile = url ? profileFromUrl(url) : null;
      const name = profile ? bestName(namesOn([anchor])) : null;
      if (profile && name) return { name, profile };
    }
    for (const heading of scope.querySelectorAll('h1, h2, [role="heading"]')) {
      const text = clean(heading.textContent);
      if (outside(heading) && isNameLike(text) && !UI_WORDS.has(text.toLowerCase()))
        return { name: text, profile: null };
    }
    const label = CONVERSATION.exec(clean(conversation.getAttribute("aria-label")));
    return { name: label?.[1] ?? null, profile: null };
  }
  function readChat(doc, address, base, options = {}) {
    return readChatIn(doc.querySelector('[role="main"]') ?? doc.body, address.thread, base, options);
  }
  function readChatIn(scope, thread, base, options = {}) {
    const conversation = conversationIn(scope);
    const { name, profile } = whoWith(scope, conversation, base);
    const sideOf = options.sideOf ?? measuredSide;
    const messages = [];
    let when = null;
    let previous = { from: "unknown", sender: null };
    const newTime = (time) => {
      when = time;
      previous = { from: "unknown", sender: null };
    };
    const rows = rowsIn(conversation);
    const isRow = new Set(rows);
    const inRow = (element) => {
      for (let e = element; e && e !== conversation; e = e.parentElement)
        if (isRow.has(e)) return true;
      return false;
    };
    for (const element of elementsIn(conversation)) {
      if (!isRow.has(element)) {
        const text = element.childElementCount === 0 ? clean(element.textContent) : "";
        if (text && isWhen(text) && !inRow(element)) newTime(text);
        continue;
      }
      const row = element;
      const message = messageIn(row);
      if (!message) {
        const time = textLines(row, 4).find(isWhen);
        if (time) newTime(time);
        continue;
      }
      let from = "unknown";
      let sender = null;
      for (const label of labelsIn(row, message.element)) {
        if (label.text === message.text) continue;
        const replied = REPLIED.exec(label.text);
        if (MINE.test(label.text) || replied?.[1]?.toLowerCase() === "you") from = "me";
        else if (replied?.[1]) [from, sender] = ["them", replied[1]];
        else if (label.heading && isNameLike(label.text)) [from, sender] = ["them", label.text];
        else continue;
        break;
      }
      if (from === "unknown")
        from = repeatedBy(message.element, message.text, conversation, isRow) ?? "unknown";
      if (from !== "me" && !sender) {
        const pictured = pictureIn(row, message.element);
        if (pictured) [from, sender] = ["them", pictured];
      }
      if (from === "unknown") {
        const side = sideOf(message.element, conversation);
        if (side) from = side === "right" ? "me" : "them";
      }
      if (from === "unknown") from = previous.from;
      if (from === "them" && !sender && previous.from === "them") sender = previous.sender;
      messages.push({ from, sender: from === "me" ? null : sender, text: message.text, when });
      previous = { from, sender };
    }
    const senders = new Set(messages.flatMap((message) => message.sender ? [message.sender] : []));
    const oneToOne = senders.size === 0 || senders.size === 1 && name !== null && senders.has(name);
    return {
      name,
      thread,
      profile,
      messages: messages.map(
        (message) => message.from === "them" && !message.sender && oneToOne ? { ...message, sender: name } : message
      )
    };
  }

  // src/facebook/friends.ts
  var YOUR_PROFILE = /^your profile$/i;
  var MUTUAL = /([\d.,]+\s*[km]?)\s+mutual\b/i;
  function yourProfile(doc, base) {
    for (const anchor of doc.querySelectorAll('[role="banner"] a[href]')) {
      if (!YOUR_PROFILE.test(labelOf(anchor))) continue;
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const profile = url ? profileFromUrl(url) : null;
      if (profile) return profile;
    }
    return null;
  }
  function friendListOf(doc, href) {
    const url = facebookUrl(href);
    if (!url) return null;
    const [first = "", second = ""] = pathParts(url).map((part) => part.toLowerCase());
    if (first === "friends")
      return second === "requests" ? "requests" : second === "list" ? "friends" : null;
    const address = classifyUrl(href);
    if (address.kind !== "friends") return null;
    if (first === "me") return "friends";
    const you = yourProfile(doc, href);
    return address.profile && you && profileKey(address.profile) === profileKey(you) ? "friends" : null;
  }
  function listBeside(href) {
    const url = facebookUrl(href);
    const [first = "", second = ""] = url ? pathParts(url).map((part) => part.toLowerCase()) : [];
    return first === "friends" && (second === "requests" || second === "list");
  }
  function readListBeside(doc, base, list) {
    for (const dialog of doc.querySelectorAll('[role="dialog"]')) {
      if (!shown(dialog)) continue;
      const people = readPeople(dialog, base, { sections: true });
      if (people.length) return withRequests(people, dialog, base, list === "requests");
    }
    let best = null;
    for (const place of doc.querySelectorAll('[role="navigation"]')) {
      if (inTopBar(place)) continue;
      const people = readPeople(place, base, { sections: true });
      if (people.length > (best?.people.length ?? 0)) best = { place, people };
    }
    return best && withRequests(best.people, best.place, base, list === "requests");
  }
  var CONFIRM = /^(?:confirm(?: friend)?(?: request)?|accept(?: request)?)(?:\s+(.+))?$/i;
  var DELETE = /^(?:delete(?: friend)?(?: request)?|remove request|decline(?: request)?)(?:\s+(.+))?$/i;
  var CANCEL = /^cancel(?: friend)? request(?:\s+(.+))?$/i;
  var ANSWERED = /^request (?:accepted|removed|deleted|declined|canceled|cancelled)$/i;
  var ROW_STEPS = 16;
  var shown = (element) => element.closest('[aria-hidden="true"]') === null;
  var shownControls = (box) => [...box.querySelectorAll('[role="button"], button')].filter(shown);
  function marksIn(root) {
    const marks = [];
    for (const element of elementsIn(root)) {
      let row = null;
      if (element.matches('[role="button"], button')) {
        const label = labelOf(element);
        row = CONFIRM.test(label) ? "received" : CANCEL.test(label) ? "sent" : null;
      } else if (element.childElementCount === 0 && ANSWERED.test(clean(element.textContent)))
        row = "answered";
      if (row && shown(element) && !inTopBar(element)) marks.push({ element, row });
    }
    return marks;
  }
  function rowOf(mark, marks, root, base) {
    let box = mark.element.parentElement;
    for (let steps = 0; box && steps < ROW_STEPS; steps++) {
      const here2 = box;
      if (marks.some((other) => other !== mark && here2.contains(other.element))) return null;
      const people = peopleLinked(here2.querySelectorAll("a[href]"), base);
      if (people.length) {
        const person = aboutWhom(people);
        return person?.inWords ? { row: mark.row, box: here2, profile: person.profile } : null;
      }
      if (here2 === root) break;
      box = here2.parentElement;
    }
    return null;
  }
  function requestRows(root, base) {
    const marks = marksIn(root);
    const rows = /* @__PURE__ */ new Map();
    for (const mark of marks) {
      const row = rowOf(mark, marks, root, base);
      if (!row) continue;
      if (row.row === "received" && !shownControls(row.box).some((c) => DELETE.test(labelOf(c))))
        continue;
      const key = profileKey(row.profile);
      const had = rows.get(key);
      if (!had || row.row === "answered" && had.row !== "answered") rows.set(key, row);
    }
    return rows;
  }
  function withRequests(people, root, base, onlyRows) {
    const rows = requestRows(root, base);
    return people.flatMap((person) => {
      const row = person.profile ? rows.get(profileKey(person.profile)) : void 0;
      if (!row) return onlyRows ? [] : [person];
      return [{ ...person, request: row.row, details: detailsIn(row.box, person.name, true) }];
    });
  }
  function mutualFriendsIn(lines) {
    for (const line of lines) {
      const match = MUTUAL.exec(clean(line));
      if (match?.[1]) return parseCount(match[1]);
    }
    return null;
  }

  // src/facebook/posts.ts
  var ACTIONS = /^actions for\b/i;
  var POST_END = /^(leave a comment|comment|see who reacted to\b.*|write a (public )?comment…?|comment as\b.*)$/i;
  var COMMENT = /^(comment|reply) by\b/i;
  var COUNT = /^[\d.,]+\s*[km]?$/i;
  var LIKE = /^(like|remove (like|love|care|haha|wow|sad|angry))$/i;
  var hasWords = (element) => clean(element.textContent) !== "";
  function postBoxes(root) {
    const fromFeeds = [...root.querySelectorAll('[role="feed"]')].flatMap(
      (feed) => [...feed.children].filter(hasWords)
    );
    if (fromFeeds.length > 0) return fromFeeds;
    const articles = [...root.querySelectorAll('[role="article"]')].filter(
      (article) => !article.parentElement?.closest('[role="article"]') && !COMMENT.test(clean(article.getAttribute("aria-label"))) && hasWords(article)
    );
    const boxes = [...articles, ...byActions(root)];
    return boxes.filter((box) => !boxes.some((other) => other !== box && other.contains(box))).sort((a, b) => isBefore(a, b) ? -1 : isBefore(b, a) ? 1 : 0);
  }
  function byActions(root) {
    const labelled = [...root.querySelectorAll("[aria-label]")].filter((e) => !inTopBar(e));
    const label = (e) => clean(e.getAttribute("aria-label"));
    const menus = labelled.filter((e) => ACTIONS.test(label(e)) && !e.closest('[role="article"]'));
    const ends = labelled.filter((e) => POST_END.test(label(e)));
    const boxes = [];
    menus.forEach((menu, i) => {
      const next = menus[i + 1];
      const end = ends.find((e) => isAfter(e, menu) && (!next || isAfter(next, e)));
      if (!end) return;
      let box = menu;
      while (!box.contains(end) && box.parentElement && box !== root) box = box.parentElement;
      if (box.contains(end) && !boxes.some((b) => b.contains(box) || box.contains(b)))
        boxes.push(box);
    });
    return boxes;
  }
  function postAround(element, root) {
    return postBoxes(root).find((box) => box !== element && box.contains(element)) ?? null;
  }
  function postBefore(element, root) {
    const before = postBoxes(root).filter((box) => isBefore(box, element) && !box.contains(element));
    const last = before[before.length - 1];
    if (!last) return null;
    const menus = [...root.querySelectorAll("[aria-label]")].filter(
      (e) => ACTIONS.test(clean(e.getAttribute("aria-label"))) && !inTopBar(e)
    );
    return menus.some((menu) => isAfter(menu, last) && isBefore(menu, element)) ? null : last;
  }
  function commentsIn(box) {
    const post = postIn(box);
    return [...post.querySelectorAll('[role="article"]')].filter((article) => article !== post);
  }
  function commentAround(element, box) {
    const post = postIn(box);
    const article = element.closest('[role="article"]');
    return article && article !== post && post.contains(article) ? article : null;
  }
  function readPosts(root, base, max = 30) {
    const posts = [];
    for (const box of postBoxes(root)) {
      const post = readPost(box, base);
      if (post) posts.push(post);
      if (posts.length >= max) break;
    }
    return posts;
  }
  function firstCount(lines, pattern) {
    for (const line of lines) {
      const match = pattern.exec(line);
      if (match?.[1]) return parseCount(match[1]);
    }
    return null;
  }
  function buttonCounts(post, inComment) {
    const buttons = [...post.querySelectorAll('[role="button"]')].filter((e) => !inComment(e));
    const label = (e) => clean(e.getAttribute("aria-label"));
    const number = (e) => {
      const text = clean(e?.textContent);
      return COUNT.test(text) ? parseCount(text) : null;
    };
    const comment2 = buttons.find((e) => /^leave a comment$/i.test(label(e)));
    const like2 = buttons.filter((e) => LIKE.test(label(e)) && (!comment2 || isBefore(e, comment2))).pop();
    return { comments: number(comment2), reactions: number(like2) };
  }
  function postIn(box) {
    if (box.matches('[role="article"]')) return box;
    const first = box.querySelector("a[href]");
    const article = outermost(box, '[role="article"]')[0];
    return article && first && article.contains(first) ? article : box;
  }
  function readPost(box, base) {
    const post = postIn(box);
    const inComment = (element) => {
      const article = element.closest('[role="article"]');
      return article !== null && article !== post && post.contains(article);
    };
    const anchors = [...post.querySelectorAll("a[href]")].filter((a) => !inComment(a));
    let url = null;
    let when = null;
    for (const anchor of anchors) {
      const link = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const permalink = link ? postUrlFrom(link) : null;
      if (!permalink) continue;
      url = permalink;
      when = clean(anchor.textContent) || clean(anchor.getAttribute("aria-label")) || null;
      break;
    }
    for (const anchor of url ? [] : post.querySelectorAll("a[href]")) {
      if (!inComment(anchor)) continue;
      const link = facebookUrl(anchor.getAttribute("href") ?? "", base);
      url = link ? postUrlFrom(link) : null;
      if (url) break;
    }
    const author = authorOf(anchors, base);
    const message = [
      ...post.querySelectorAll('[data-ad-comet-preview="message"], [data-ad-preview="message"]')
    ].find((element) => !inComment(element));
    let text = message ? textLines(message, 200, '[role="button"]').join("\n") : "";
    if (!text) {
      for (const element of post.querySelectorAll('[dir="auto"]')) {
        if (inComment(element) || element.closest(
          'h1, h2, h3, h4, h5, h6, [role="heading"], [role="button"], [aria-hidden="true"]'
        ))
          continue;
        const candidate = clean(element.textContent);
        if (candidate.length > text.length && candidate !== author?.name) text = candidate;
      }
    }
    const lines = textLines(post, 120, '[role="article"]');
    const counted2 = buttonCounts(post, inComment);
    const comments = firstCount(lines, /^([\d.,]+\s*[km]?)\s+comments?$/i) ?? counted2.comments;
    const reactions = firstCount(lines, /^all reactions:?\s*([\d.,]+\s*[km]?)$/i) ?? counted2.reactions;
    if (!author && !text) return null;
    return { author, url, when, text, comments, reactions };
  }
  function authorOf(anchors, base) {
    const profiles = anchors.flatMap((anchor) => {
      const link = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const profile = link ? profileFromUrl(link) : null;
      if (!profile) return [];
      const name = bestName(textLines(anchor, 1));
      return name ? [{ anchor, named: { name, profile } }] : [];
    });
    const fromHeading = profiles.find(
      ({ anchor }) => Boolean(anchor.closest('h1, h2, h3, h4, h5, h6, [role="heading"], strong'))
    );
    return (fromHeading ?? profiles[0])?.named ?? null;
  }

  // src/facebook/profile.ts
  var FRIENDSHIP = [
    [/^edit profile$/i, "self"],
    [/^friends$/i, "friends"],
    [/^cancel request$/i, "request_sent"],
    [/^(respond|confirm|confirm request)$/i, "request_received"],
    [/^add friend$/i, "not_friends"]
  ];
  var AFTER_INTRO = /^(photos|friends|featured|life events|posts|links|hobbies|interests|about|see all.*)$/i;
  var NOT_INTRO = /\bmutual\b|^followed by\b/i;
  var NOT_TOP_TEXT = 'h1, h2, h3, [role="heading"], [role="button"], button, [role="tablist"]';
  function friendshipIn(labels) {
    for (const [pattern, friendship] of FRIENDSHIP)
      if (labels.some((label) => pattern.test(label))) return friendship;
    return "unknown";
  }
  function nameFromTitle(title) {
    const name = clean(title).replace(/^\(\d+\+?\)\s*/, "").replace(/\s*\|\s*facebook$/i, "");
    return isNameLike(name) ? name : null;
  }
  function nameFromLinks(root, address, base) {
    if (!address.profile) return null;
    const key = profileKey(address.profile);
    const anchors = [...root.querySelectorAll("a[href]")].filter((anchor) => {
      if (inTopBar(anchor)) return false;
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const profile = url ? profileFromUrl(url) : null;
      return profile !== null && profileKey(profile) === key;
    });
    return bestName(namesOn(anchors));
  }
  function nameElementIn(root, name) {
    for (const element of elementsIn(root))
      if (element.childElementCount === 0 && clean(element.textContent) === name && !inTopBar(element))
        return element;
    return null;
  }
  function topOf(root, name) {
    for (let box = tabsIn(root); box && box !== root; box = box.parentElement) {
      const before = [];
      for (let e = box.previousElementSibling; e; e = e.previousElementSibling) before.unshift(e);
      const isTop = (e) => friendshipIn(buttonLabels(e)) !== "unknown" || name !== null && textLines(e, 30).some((line) => line.startsWith(name));
      if (before.some(isTop)) return before;
    }
    return [];
  }
  function headerAround(name, root) {
    let box = name;
    for (let steps = 0; box && steps < 12; steps++) {
      if (friendshipIn(buttonLabels(box)) !== "unknown") return box;
      if (box === root) break;
      box = box.parentElement;
    }
    return null;
  }
  function topLines(top, name) {
    return top.flatMap((box) => textLines(box, 40, NOT_TOP_TEXT)).filter(
      (line) => !(name && line.startsWith(name)) && !isFacebookLine(line) && !NOT_INTRO.test(line) && line.length <= 300
    );
  }
  function introLines(root) {
    const title = [...elementsIn(root)].find(
      (element) => (isHeading(element) || element.childElementCount === 0) && clean(element.textContent).toLowerCase() === "intro"
    );
    if (!title) return [];
    let column = title;
    for (let steps = 0; steps < 10 && column.parentElement && column !== root; steps++) {
      const up = column.parentElement;
      if (textLines(up, 1)[0]?.toLowerCase() !== "intro") break;
      column = up;
    }
    const lines = [];
    for (const line of textLines(column, 40).slice(1)) {
      if (AFTER_INTRO.test(line)) break;
      if (UI_WORDS.has(line.toLowerCase()) || isFacebookText(line)) continue;
      lines.push(line);
      if (lines.length >= 12) break;
    }
    return lines;
  }
  var PAGES_MOST = 3;
  function pagesIn(root, address, base, name, intro) {
    const self = address.profile ? profileKey(address.profile) : null;
    const found = [];
    const seen = /* @__PURE__ */ new Set();
    for (const anchor of root.querySelectorAll("a[href]")) {
      if (inTopBar(anchor)) continue;
      const words2 = clean(anchor.textContent);
      if (words2.length < 2 || words2.length > 100 || words2 === name) continue;
      if (!intro.some((line) => line.includes(words2))) continue;
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const profile = url ? profileFromUrl(url) : null;
      if (!profile) continue;
      const key = profileKey(profile);
      if (key === self || seen.has(key)) continue;
      seen.add(key);
      found.push({ name: words2, profile });
      if (found.length >= PAGES_MOST) break;
    }
    return found;
  }
  function readProfile(root, address, base, title = "") {
    const heading = root.querySelector("h1");
    const headingName = heading ? clean(heading.textContent) : "";
    const name = (isNameLike(headingName) ? headingName : null) ?? nameFromTitle(title) ?? nameFromLinks(root, address, base);
    let top = topOf(root, name);
    if (top.length === 0) {
      const around = heading ?? (name ? nameElementIn(root, name) : null);
      const header = around ? headerAround(around, root) : null;
      top = header ? [header] : [];
    }
    const friendship = friendshipIn(top.flatMap(buttonLabels));
    let mutualFriends = null;
    for (const line of top.flatMap((box) => textLines(box, 40))) {
      const match = /([\d.,]+\s*[km]?)\s+mutual\b/i.exec(line);
      if (match?.[1]) {
        mutualFriends = parseCount(match[1]);
        break;
      }
    }
    const intro = [.../* @__PURE__ */ new Set([...topLines(top, name), ...introLines(root)])].slice(0, 12);
    return {
      profile: { name, profile: address.profile, intro, friendship, mutualFriends },
      posts: readPosts(root, base),
      pages: pagesIn(root, address, base, name, intro)
    };
  }

  // src/facebook/actions.ts
  var ADD_FRIEND = /^add friend(?:\s+(.+))?$/i;
  var LIKE2 = /^like$/i;
  var COMMENT_BOX = /^(comment as\b|write a (public )?comment|reply (to|as)\b|write a (public )?reply|answer as\b|write an answer)/i;
  var REPLY_BOX = /^(reply (to|as)\b|write a (public )?reply)/i;
  var REPLY_TO = /^reply to\s+(.+?)(?:…|\.\.\.)?$/i;
  var MESSAGE_BOX = /^(message\b|aa$|write (a message|to)\b|type a message)/i;
  var SEND = /^(press enter to send|send|comment|post comment|post reply|submit)$/i;
  var WRITING_AS = /^(?:comment|reply|answer) as\s+(.+?)(?:…|\.\.\.)?$/i;
  var YOUR_PROFILE2 = /^your profile$/i;
  var CARD_STEPS = 16;
  var SEND_STEPS = 12;
  var WINDOW_STEPS = 20;
  var WRITING = '[role="textbox"], [contenteditable="true"]';
  var mainOf = (doc) => doc.querySelector('[role="main"]') ?? doc.body;
  function rootOf(element, doc) {
    const dialog = element.closest('[role="dialog"]');
    if (dialog) return dialog;
    const main = mainOf(doc);
    return main.contains(element) ? main : doc.body;
  }
  var urlOf = (anchor, base) => facebookUrl(anchor.getAttribute("href") ?? "", base);
  var reachedOf = (named) => named?.profile && named.name ? { name: named.name, profile: named.profile } : null;
  function isYou(person, doc, base) {
    const key = profileKey(person.profile);
    for (const anchor of doc.querySelectorAll('[role="banner"] a[href]')) {
      if (!YOUR_PROFILE2.test(labelOf(anchor))) continue;
      const url = urlOf(anchor, base);
      const profile = url ? profileFromUrl(url) : null;
      if (profile && profileKey(profile) === key) return true;
    }
    for (const box of doc.querySelectorAll('[role="textbox"][aria-label]')) {
      const yours = WRITING_AS.exec(clean(box.getAttribute("aria-label")))?.[1];
      if (yours && person.name && sameName(yours, person.name)) return true;
    }
    return false;
  }
  var hasWriting = (box) => textWithEmoji(box) !== "";
  function groupName(group, doc, address, base) {
    const key = group.id.toLowerCase();
    const onItsPage = (address.kind === "group" || address.kind === "group-members") && address.group?.id.toLowerCase() === key;
    if (onItsPage) {
      const heading = clean(mainOf(doc).querySelector("h1")?.textContent);
      const name = (isNameLike(heading) ? heading : null) ?? nameFromTitle(doc.title);
      if (name) return name;
    }
    const anchors = [...doc.querySelectorAll("a[href]")].filter((anchor) => {
      const url = urlOf(anchor, base);
      return url !== null && pathParts(url).length === 2 && groupFromUrl(url)?.id.toLowerCase() === key && !inTopBar(anchor);
    });
    return bestName(namesOn(anchors));
  }
  function groupInPost(box, base) {
    for (const anchor of box.querySelectorAll("a[href]")) {
      if (commentAround(anchor, box)) continue;
      const url = urlOf(anchor, base);
      const group = url ? groupFromUrl(url) : null;
      if (group) return group;
    }
    return null;
  }
  function groupOf(post, doc, address, base) {
    const group = address.group ?? (post ? groupInPost(post, base) : null);
    return group ? { ...group, name: groupName(group, doc, address, base) } : null;
  }
  function pagePerson(doc, address, base) {
    if (address.kind !== "profile" || !address.profile) return null;
    const main = mainOf(doc);
    const key = profileKey(address.profile);
    const linked = peopleLinked(main.querySelectorAll("a[href]"), base).find(
      (person) => profileKey(person.profile) === key
    )?.name;
    const heading = address.group ? "" : clean(main.querySelector("h1")?.textContent);
    const name = (isNameLike(heading) ? heading : null) ?? (address.group ? null : nameFromTitle(doc.title)) ?? linked;
    return name ? { name, profile: address.profile } : null;
  }
  function personNear(control, root, base, named) {
    let box = control;
    for (let steps = 0; box && steps < CARD_STEPS; steps++) {
      const people = peopleLinked(box.querySelectorAll("a[href]"), base);
      if (people.length > 0) {
        if (named) {
          const match = people.find((person3) => person3.name && sameName(person3.name, named));
          const only = people.length === 1 ? people[0] : void 0;
          const person2 = match ?? only;
          return person2 ? { name: named, profile: person2.profile } : null;
        }
        const person = aboutWhom(people);
        return person?.name ? { name: person.name, profile: person.profile } : null;
      }
      if (box === root) break;
      box = box.parentElement;
    }
    return null;
  }
  function friendRequest(control, label, doc, href) {
    const address = classifyUrl(href);
    const main = mainOf(doc);
    const root = rootOf(control, doc);
    const named = clean(ADD_FRIEND.exec(label)?.[1]) || null;
    let to = null;
    const page = main.contains(control) ? pagePerson(doc, address, href) : null;
    if (page) {
      const tabs = tabsIn(main);
      if (tabs && isBefore(control, tabs) || named && sameName(named, page.name)) to = page;
    }
    to ??= personNear(control, root, href, named);
    if (!to || isYou(to, doc, href)) return null;
    return {
      kind: "friend_request",
      to,
      group: groupOf(postAround(control, root), doc, address, href),
      postUrl: null,
      thread: null,
      replying: null
    };
  }
  function commentAuthor(article, base) {
    const own = [...article.querySelectorAll("a[href]")].filter(
      (anchor) => anchor.closest('[role="article"]') === article
    );
    const first = peopleLinked(own, base)[0];
    return first?.name ? { name: first.name, profile: first.profile } : null;
  }
  function like(control, doc, href) {
    const root = rootOf(control, doc);
    const box = postAround(control, root);
    if (!box) return null;
    const post = readPost(box, href);
    const comment2 = commentAround(control, box);
    const to = comment2 ? commentAuthor(comment2, href) : reachedOf(post?.author);
    if (!to || isYou(to, doc, href)) return null;
    return {
      kind: "like",
      to,
      group: groupOf(box, doc, classifyUrl(href), href),
      postUrl: post?.url ?? null,
      thread: null,
      replying: null
    };
  }
  function comment(box, postBox, label, doc, address, base) {
    const post = readPost(postBox, base);
    const comments = commentsIn(postBox);
    const reply = REPLY_BOX.test(label) || commentAround(box, postBox) !== null || !COMMENT_BOX.test(label) && comments.some((article) => isAfter(article, box));
    let to = null;
    if (reply) {
      const named = clean(REPLY_TO.exec(label)?.[1]) || null;
      const above = comments.filter((article) => isBefore(article, box)).map((article) => commentAuthor(article, base)).filter((author) => author !== null).reverse();
      to = (named ? above.find((author) => sameName(author.name, named)) : void 0) ?? above[0] ?? null;
    }
    to ??= reachedOf(post?.author);
    if (!to || isYou(to, doc, base)) return null;
    return {
      kind: "comment",
      to,
      group: groupOf(postBox, doc, address, base),
      postUrl: post?.url ?? null,
      thread: null,
      replying: null
    };
  }
  function messageTo(chat, doc, base) {
    if (!chat.profile || !chat.name) return null;
    const to = { name: chat.name, profile: chat.profile };
    if (isYou(to, doc, base)) return null;
    const last = chat.messages[chat.messages.length - 1];
    return {
      kind: "message",
      to,
      group: null,
      postUrl: null,
      thread: chat.thread,
      replying: !last ? false : last.from === "unknown" ? null : last.from === "them"
    };
  }
  function threadLinkedIn(box, base) {
    for (const anchor of box.querySelectorAll("a[href]")) {
      const url = urlOf(anchor, base);
      const thread = url ? threadFromUrl(url) : null;
      if (thread) return thread;
    }
    return null;
  }
  function chatWindowOf(box, doc, base) {
    const chats = [...doc.querySelectorAll("[aria-label]")].filter(isConversation);
    if (chats.length === 0) return null;
    const boxes = [...doc.querySelectorAll(WRITING)];
    const root = rootOf(box, doc);
    const main = mainOf(doc);
    for (let up = box.parentElement; up && root.contains(up); up = up.parentElement) {
      const here2 = up;
      if (here2.contains(main)) break;
      const inside = chats.filter((chat2) => here2.contains(chat2));
      if (inside.length > 1 || boxes.filter((other) => here2.contains(other)).length > 1) return null;
      const chat = inside[0];
      if (!chat) continue;
      const outside = [...here2.querySelectorAll("a[href]")].filter(
        (anchor) => !chat.contains(anchor)
      );
      if (peopleLinked(outside, base).length > 0) return here2;
    }
    return null;
  }
  function messageNear(box, doc, base) {
    const main = mainOf(doc);
    let up = box.parentElement;
    for (let steps = 0; up && steps < WINDOW_STEPS && !up.contains(main); steps++) {
      const people = peopleLinked(up.querySelectorAll("a[href]"), base);
      if (people.length > 0) {
        const person = people[0];
        if (people.length > 1 || up.querySelectorAll(WRITING).length > 1 || !person.name) return null;
        const to = { name: person.name, profile: person.profile };
        if (isYou(to, doc, base)) return null;
        return {
          kind: "message",
          to,
          group: null,
          postUrl: null,
          thread: threadLinkedIn(up, base),
          replying: null
        };
      }
      up = up.parentElement;
    }
    return null;
  }
  function written(box, doc, href) {
    const address = classifyUrl(href);
    if (address.kind === "chat" && mainOf(doc).contains(box))
      return messageTo(readChat(doc, address, href), doc, href);
    const chatWindow = chatWindowOf(box, doc, href);
    if (chatWindow)
      return messageTo(readChatIn(chatWindow, threadLinkedIn(chatWindow, href), href), doc, href);
    const label = clean(box.getAttribute("aria-label")) || clean(box.getAttribute("aria-placeholder"));
    const root = rootOf(box, doc);
    const commentBox2 = COMMENT_BOX.test(label);
    const post = postAround(box, root) ?? (commentBox2 ? postBefore(box, root) : null);
    if (post && (commentBox2 || !MESSAGE_BOX.test(label)))
      return comment(box, post, label, doc, address, href);
    return MESSAGE_BOX.test(label) ? messageNear(box, doc, href) : null;
  }
  function boxSentBy(control) {
    let up = control.parentElement;
    for (let steps = 0; up && steps < SEND_STEPS; steps++) {
      const boxes = [...up.querySelectorAll(WRITING)];
      if (boxes.length > 0) {
        const box = boxes.filter((b) => isBefore(b, control)).pop();
        return box && hasWriting(box) ? box : null;
      }
      up = up.parentElement;
    }
    return null;
  }
  function stepFromClick(target, doc, href) {
    const control = target.closest('[role="button"], button');
    if (!control || inTopBar(control) || control.getAttribute("aria-disabled") === "true")
      return null;
    const label = labelOf(control);
    if (ADD_FRIEND.test(label)) return friendRequest(control, label, doc, href);
    if (LIKE2.test(label)) return like(control, doc, href);
    if (SEND.test(label)) {
      const box = boxSentBy(control);
      return box ? written(box, doc, href) : null;
    }
    return null;
  }
  function stepFromEnter(target, doc, href) {
    const box = target.closest(WRITING);
    if (!box || inTopBar(box) || !hasWriting(box)) return null;
    if (box.getAttribute("aria-expanded") === "true" || box.getAttribute("aria-activedescendant"))
      return null;
    return written(box, doc, href);
  }
  function seenFromClick(target, doc, href) {
    const anchor = target.closest("a[href]");
    if (!anchor || inTopBar(anchor)) return null;
    const url = urlOf(anchor, href);
    const profile = url ? profileFromUrl(url) : null;
    if (!url || !profile) return null;
    const address = classifyUrl(href);
    const root = rootOf(anchor, doc);
    const linked = groupFromUrl(url);
    const group = linked ? { ...linked, name: groupName(linked, doc, address, href) } : groupOf(postAround(anchor, root), doc, address, href);
    if (!group) return null;
    const name = bestName(namesOn([anchor]));
    return isYou({ profile, name }, doc, href) ? null : { profile, name, group };
  }
  var MENU_CONFIRM = /^confirm(?: request)?$/i;
  var MENU_DELETE = /^delete(?: friend)? request$/i;
  var RESPOND = /^respond$/i;
  var controlsIn = (box) => [...box.querySelectorAll('[role="button"], button')].filter(shown);
  function requestButtons(control, other, root) {
    let box = control.parentElement;
    for (let steps = 0; box && steps < CARD_STEPS; steps++) {
      const others = controlsIn(box).filter(
        (found) => found !== control && other.test(labelOf(found))
      );
      if (others.length) return others.length === 1 ? box : null;
      if (box === root) break;
      box = box.parentElement;
    }
    return null;
  }
  var keysOf = (profile) => [
    profileKey(profile),
    ...profile.id && profile.username ? [profileKey({ ...profile, id: null })] : []
  ];
  function cardOf2(control, to, root, base) {
    const keys = keysOf(to.profile);
    let box = control.parentElement;
    for (let steps = 0; box && steps < CARD_STEPS; steps++) {
      const linked = peopleLinked(box.querySelectorAll("a[href]"), base);
      if (linked.some((person) => keys.includes(profileKey(person.profile)))) return box;
      if (box === root) break;
      box = box.parentElement;
    }
    return null;
  }
  function previewPerson(doc, href) {
    const url = facebookUrl(href);
    if (!url || pathParts(url)[0]?.toLowerCase() !== "friends") return null;
    const number = profileFromUrl(url);
    if (!number) return null;
    const main = mainOf(doc);
    const tabs = tabsIn(main);
    const tabbed = tabs ? [...tabs.querySelectorAll("a[href]")].flatMap((tab) => {
      const profile2 = classifyUrl(urlOf(tab, href)?.href ?? "").profile;
      return profile2 ? [profile2] : [];
    }) : [];
    const usernames = new Set(tabbed.flatMap((p) => p.username ? [p.username.toLowerCase()] : []));
    const username = usernames.size === 1 && tabbed.some((p) => p.id === number.id) ? tabbed.find((p) => p.username)?.username ?? null : null;
    const profile = { ...number, username };
    const keys = keysOf(profile);
    const anchors = [...doc.querySelectorAll("a[href]")].filter((anchor) => {
      if (inTopBar(anchor)) return false;
      const linked = urlOf(anchor, href);
      const person = linked ? profileFromUrl(linked) : null;
      return person !== null && keys.includes(profileKey(person));
    });
    const heading = clean(main.querySelector("h1")?.textContent);
    const name = bestName(namesOn(anchors)) ?? (isNameLike(heading) ? heading : null);
    return name ? { name, profile } : null;
  }
  function mutualFriendsBeside(doc, to, base) {
    const keys = keysOf(to.profile);
    for (const list of doc.querySelectorAll('[role="navigation"]')) {
      if (inTopBar(list)) continue;
      const rows = requestRows(list, base);
      const row = keys.map((key) => rows.get(key)).find((found) => found !== void 0);
      if (row) return mutualFriendsIn(textLines(row.box, 12));
    }
    return null;
  }
  function answerFromClick(target, doc, href) {
    const item = target.closest('[role="menuitem"]');
    if (item) {
      const label2 = labelOf(item);
      const answer2 = MENU_CONFIRM.test(label2) ? "confirm" : MENU_DELETE.test(label2) ? "delete" : null;
      const address2 = classifyUrl(href);
      const main2 = mainOf(doc);
      const responding = controlsIn(main2).some((control2) => RESPOND.test(labelOf(control2)));
      const to2 = answer2 && responding ? pagePerson(doc, address2, href) ?? previewPerson(doc, href) : null;
      if (!answer2 || !to2 || isYou(to2, doc, href)) return null;
      return { answer: answer2, to: to2, mutualFriends: mutualFriendsBeside(doc, to2, href) };
    }
    const control = target.closest('[role="button"], button');
    if (!control || inTopBar(control) || control.getAttribute("aria-disabled") === "true")
      return null;
    const label = labelOf(control);
    const confirm = CONFIRM.exec(label);
    const remove = confirm ? null : DELETE.exec(label);
    if (!confirm && !remove) return null;
    const answer = confirm ? "confirm" : "delete";
    const root = rootOf(control, doc);
    if (!requestButtons(control, confirm ? DELETE : CONFIRM, root)) return null;
    const named = clean((confirm ?? remove)?.[1]) || null;
    const address = classifyUrl(href);
    const main = mainOf(doc);
    let to = null;
    if (main.contains(control)) {
      const page = pagePerson(doc, address, href) ?? previewPerson(doc, href);
      const tabs = tabsIn(main);
      if (page && (!tabs || isBefore(control, tabs) || named && sameName(named, page.name)))
        to = page;
    }
    to ??= personNear(control, root, href, named);
    if (!to || isYou(to, doc, href)) return null;
    const card = cardOf2(control, to, root, href);
    const mutualFriends = (card ? mutualFriendsIn(textLines(card, 12)) : null) ?? mutualFriendsBeside(doc, to, href);
    return { answer, to, mutualFriends };
  }

  // src/facebook/fetch.ts
  var DOWNLOAD_PAGE = "https://accountscenter.facebook.com/info_and_permissions/dyi/";
  var CHATS_PAGE = "https://www.facebook.com/messages/";
  var press = (words2, says2, more = {}) => ({ action: "press", words: words2, says: says2, ...more });
  var SAVE = ["Save", "Done", "Confirm"];
  var FETCH_PLANS = {
    request: {
      job: "request",
      url: DOWNLOAD_PAGE,
      mode: "steps",
      steps: [
        {
          action: "stopIf",
          words: ["Your information is being prepared"],
          optional: true,
          says: "Facebook is already making your file. It emails you when it’s ready; then press Download my file."
        },
        press(
          [
            "Create export",
            "Export your information",
            "Download or transfer information",
            "Download your information"
          ],
          "Press “Create export”."
        ),
        press(["Facebook"], "Press your Facebook profile.", { anywhere: true, optional: true }),
        press(["Export to device", "Download to device"], "Press “Export to device”.", {
          optional: true
        }),
        press(
          [
            "Customize information",
            "Some of your information",
            "Specific types of information",
            "Select types of information"
          ],
          "Press “Customize information”."
        ),
        press(["Clear all"], "Press “Clear all” in each part of the list.", {
          exact: true,
          every: true,
          optional: true
        }),
        { action: "tick", words: ["Messages"], says: "Tick “Messages”." },
        {
          action: "tick",
          words: ["Friends", "Friends and followers"],
          exact: true,
          says: "Tick “Friends”."
        },
        {
          action: "tick",
          words: ["Followers"],
          exact: true,
          optional: true,
          says: "Tick “Followers”."
        },
        press(SAVE, "Press “Save”.", { exact: true }),
        press(["Date range"], "Set “Date range” to “All time”.", { optional: true }),
        {
          action: "pick",
          words: ["All time"],
          afterPrevious: true,
          says: "Pick “All time”, then press “Save”."
        },
        press(SAVE, "Press “Save”.", { optional: true, afterPrevious: true, exact: true }),
        press(["Format"], "Set “Format” to “JSON”."),
        {
          action: "pick",
          words: ["JSON"],
          afterPrevious: true,
          says: "Pick “JSON”, then press “Save”."
        },
        press(SAVE, "Press “Save”.", { optional: true, afterPrevious: true, exact: true }),
        press(["Media quality"], "Set “Media quality” to “Lower quality”.", { optional: true }),
        {
          action: "pick",
          words: ["Lower quality", "Low"],
          afterPrevious: true,
          says: "Pick “Lower quality”, then press “Save”."
        },
        press(SAVE, "Press “Save”.", { optional: true, afterPrevious: true, exact: true }),
        press(["Start export", "Create files", "Create export"], "Press “Start export”.", {
          exact: true
        })
      ]
    },
    download: {
      job: "download",
      url: DOWNLOAD_PAGE,
      mode: "steps",
      steps: [
        press(
          ["Current activity", "Available downloads", "Available files"],
          "Open “Current activity”.",
          { optional: true }
        ),
        press(["Download"], "Press “Download” beside your file.", { exact: true })
      ]
    },
    backup: {
      job: "backup",
      url: CHATS_PAGE,
      mode: "path",
      steps: [
        press(
          ["Settings, help and more", "Options", "Chat settings", "Messenger settings"],
          "Press the ⋯ button next to Chats.",
          { exact: true, beside: ["Chats"] }
        ),
        press(["Privacy & safety", "Privacy and safety"], "Press “Privacy & safety”."),
        press(["End-to-end encrypted chats"], "Press “End-to-end encrypted chats”."),
        press(["Message storage", "Chat history"], "Press “Message storage”."),
        press(
          ["Download message storage data", "Download secure storage data"],
          "Press “Download message storage data”."
        )
      ],
      then: [
        {
          action: "pick",
          words: ["All time", "From account creation"],
          says: "Pick “All time”."
        },
        { action: "untick", words: ["Media"], exact: true, optional: true, says: "Untick “Media”." },
        press(["Download file", "Download"], "Press “Download file”.", { exact: true })
      ]
    }
  };
  var FETCH_WORDS = new Set(
    [
      ...Object.values(FETCH_PLANS).flatMap((plan) => plan.steps.flatMap((step) => step.words)),
      "Preferences",
      "Message requests",
      "Archived chats",
      "Restricted accounts",
      "Blocked accounts",
      "Help",
      "Who can message you",
      "Message delivery",
      "Read receipts",
      "Active status",
      "End-to-end encryption",
      "Secure storage",
      "Logins",
      "Security alerts",
      "Turn off secure storage",
      "Reset PIN",
      "Change PIN",
      "Your information",
      "Export your information"
    ].map((word) => word.toLowerCase())
  );
  function fetchPage(href) {
    let url;
    try {
      url = new URL(href);
    } catch {
      return false;
    }
    if (url.protocol !== "https:") return false;
    const host = url.hostname.toLowerCase();
    if (host === "accountscenter.facebook.com")
      return url.pathname.startsWith("/info_and_permissions");
    if (host === "www.facebook.com" || host === "web.facebook.com")
      return /^\/(messages|dyi|download|secure_storage)(\/|$)/.test(url.pathname);
    return false;
  }
  var PRESSES = [
    "button",
    "a[href]",
    '[role="button"]',
    '[role="link"]',
    '[role="menuitem"]',
    '[role="tab"]',
    '[role="option"]',
    '[role="listitem"][tabindex]'
  ].join(", ");
  var BUTTONS = 'button, [role="button"]';
  var TICKS = 'input[type="checkbox"], [role="checkbox"], [role="switch"]';
  var PICKS = 'input[type="radio"], [role="radio"], [role="menuitemradio"], [role="option"], [role="menuitem"]';
  var ROWS = 'label, [role="listitem"], [role="row"], [role="option"], li';
  function shown2(element) {
    if (element.closest('[aria-hidden="true"], [hidden], [inert]')) return false;
    if (element.getAttribute("aria-disabled") === "true" || element.hasAttribute("disabled"))
      return false;
    const style = element.ownerDocument.defaultView?.getComputedStyle(element);
    return !style || style.display !== "none" && style.visibility !== "hidden";
  }
  function nameOf(element) {
    const label = clean(element.getAttribute("aria-label"));
    if (label) return label;
    const doc = element.ownerDocument;
    const by = (element.getAttribute("aria-labelledby") ?? "").split(/\s+/).map((id2) => id2 ? clean(doc.getElementById(id2)?.textContent) : "").filter(Boolean).join(" ");
    if (by) return by;
    const id = element.getAttribute("id");
    const forIt = id ? [...doc.querySelectorAll("label[for]")].find((l) => l.getAttribute("for") === id) : null;
    if (forIt) return clean(textPieces(forIt).join(" "));
    return clean(textPieces(element).join(" "));
  }
  function boxName(element) {
    const row = element.closest(ROWS);
    return nameOf(element) || (row ? clean(textPieces(row).join(" ")) : "");
  }
  function fit(name, word, step) {
    const a = name.toLowerCase();
    const b = word.toLowerCase();
    if (a === b) return 2;
    if (step.exact) return 0;
    if (a.startsWith(b) && /^[\s:,.·–—-]/.test(a.slice(b.length))) return 1;
    if (step.anywhere && new RegExp(`\\b${b.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(a))
      return 1;
    return 0;
  }
  function placesOf(doc) {
    const over = [...doc.querySelectorAll('[role="dialog"], [role="menu"], [role="listbox"]')].filter(
      shown2
    );
    const top = over.at(-1);
    if (!top) return [doc.body];
    const menus = over.filter((box) => box !== top && box.getAttribute("role") === "menu");
    return [top, ...menus.reverse()];
  }
  function besideHeading(place, headings) {
    const wanted = headings.map((h) => h.toLowerCase());
    const found = [...place.querySelectorAll('h1, h2, h3, h4, h5, h6, [role="heading"]')].filter(
      (h) => shown2(h) && wanted.includes(clean(h.textContent).toLowerCase())
    );
    for (const heading of found) {
      let box = heading.parentElement;
      for (let up = 0; box && up < 8 && place.contains(box); up++, box = box.parentElement) {
        const opener = [...box.querySelectorAll("[aria-expanded], [aria-haspopup]")].find(
          (element) => element.matches(PRESSES) && shown2(element) && isAfter(element, heading)
        );
        if (opener) return opener;
      }
    }
    return null;
  }
  function candidatesFor(doc, step) {
    const selector = step.action === "press" ? step.buttonsOnly ? BUTTONS : PRESSES : step.action === "pick" ? PICKS : TICKS;
    const name = step.action === "press" ? nameOf : boxName;
    const places = placesOf(doc).filter((place) => !step.inBox || place !== doc.body);
    if (!places.length) return [];
    for (const place of places) {
      const candidates = [...place.querySelectorAll(selector)].filter(shown2);
      for (const word of step.words) {
        const fits = candidates.map((element) => ({ element, fit: fit(name(element), word, step) })).filter((c) => c.fit > 0);
        if (fits.length === 0) continue;
        const best = Math.max(...fits.map((c) => c.fit));
        return fits.filter((c) => c.fit === best).map((c) => c.element);
      }
    }
    const beside = step.beside ? besideHeading(places[0], step.beside) : null;
    return beside ? [beside] : [];
  }
  function findStep(doc, step) {
    if (step.action === "stopIf") return null;
    return candidatesFor(doc, step)[0] ?? null;
  }
  function says(doc, words2) {
    const text = clean(textPieces(placesOf(doc)[0]).join(" ")).toLowerCase();
    return words2.some((word) => text.includes(word.toLowerCase()));
  }
  function chosen(element) {
    if (element instanceof element.ownerDocument.defaultView.HTMLInputElement)
      return element.checked;
    return element.getAttribute("aria-checked") === "true" || element.getAttribute("aria-selected") === "true";
  }
  function waitingForPerson(doc) {
    return [
      ...doc.querySelectorAll(
        'input[type="password"], input[autocomplete="one-time-code"], input[inputmode="numeric"]'
      )
    ].some(shown2);
  }
  function doStep(doc, step) {
    if (step.action === "stopIf") return says(doc, step.words) ? "stop" : "missing";
    const found = candidatesFor(doc, step);
    const element = found[0];
    if (!element) return waitingForPerson(doc) ? "waiting" : "missing";
    if (step.action === "untick") {
      if (!chosen(element)) return "already";
    } else if (step.action !== "press" && chosen(element)) return "already";
    for (const each of step.every ? found : [element]) each.click();
    return "done";
  }
  function doPath(doc, steps, from) {
    for (let i = steps.length - 1; i >= from; i--) {
      const element = findStep(doc, steps[i]);
      if (!element) continue;
      element.click();
      return { at: i };
    }
    return { result: waitingForPerson(doc) ? "waiting" : "missing" };
  }

  // src/facebook/auto.ts
  var press2 = (words2, says2, more = {}) => ({ action: "press", words: words2, says: says2, ...more });
  var AUTO_PLANS = {
    friend_request: {
      before: "not_friends",
      after: "request_sent",
      path: [
        press2(["Add friend", "Add Friend"], "Press “Add friend” under their name.", {
          exact: true,
          buttonsOnly: true
        })
      ],
      // Some accounts are asked whether they know the person first.
      then: [
        press2(["Confirm", "Send request", "Send friend request"], "Press “Confirm”.", {
          exact: true,
          inBox: true,
          optional: true
        })
      ]
    },
    confirm: {
      before: "request_received",
      after: "friends",
      // Respond opens a menu with Confirm in it; some profiles show Confirm request straight away.
      path: [
        press2(["Respond", "Confirm request", "Confirm"], "Press “Respond” under their name.", {
          exact: true,
          buttonsOnly: true
        })
      ],
      then: [
        press2(["Confirm", "Confirm request"], "Press “Confirm”.", {
          exact: true,
          inBox: true,
          optional: true
        })
      ]
    }
  };
  var MESSAGE_PATH = [
    press2(["Message"], "Press “Message” under their name.", { exact: true })
  ];
  function sameRef(a, b) {
    if (!a || !b) return false;
    if (a.id && b.id) return a.id === b.id;
    if (a.username && b.username) return a.username.toLowerCase() === b.username.toLowerCase();
    return a.url === b.url;
  }
  var pause = (ms) => new Promise((done) => setTimeout(done, ms));
  var mainOf2 = (doc) => doc.querySelector('[role="main"]') ?? doc.body;
  function likeButton(box) {
    return [...box.querySelectorAll('[role="button"], button')].find((button) => {
      if (!LIKE.test(clean(button.getAttribute("aria-label"))) || !shown2(button)) return false;
      const article = button.closest('[role="article"]');
      if (!article || article !== box && !box.contains(article)) return true;
      const outer = article.parentElement?.closest('[role="article"]');
      return !(outer && (outer === box || box.contains(outer))) && !COMMENT.test(clean(article.getAttribute("aria-label")));
    }) ?? null;
  }
  function theirPost(doc, href, profile) {
    for (const box of postBoxes(mainOf2(doc))) {
      const post = readPost(box, href);
      if (post?.author && sameRef(post.author.profile, profile)) return { box, url: post.url };
    }
    return null;
  }
  async function likeLatest(doc, href, profile, view) {
    let found = theirPost(doc, href, profile);
    for (let more = 0; !found && more < 4; more++) {
      view.scrollBy(0, view.innerHeight);
      await pause(1200);
      found = theirPost(doc, href, profile);
    }
    if (!found) return { result: "none", postUrl: null };
    const button = likeButton(found.box);
    if (!button) return { result: "none", postUrl: found.url };
    if (!/^like$/i.test(clean(button.getAttribute("aria-label"))))
      return { result: "already", postUrl: found.url };
    button.click();
    return { result: "done", postUrl: found.url };
  }
  function commentBox(doc) {
    const label = (box2) => clean(box2.getAttribute("aria-label")) || clean(box2.getAttribute("aria-placeholder"));
    const dialog = [...doc.querySelectorAll('[role="dialog"]')].filter(shown2).at(-1);
    const root = dialog ?? mainOf2(doc);
    const box = [...root.querySelectorAll(WRITING)].find(
      (b) => shown2(b) && !inTopBar(b) && COMMENT_BOX.test(label(b)) && !REPLY_BOX.test(label(b))
    );
    return box ?? null;
  }
  function sendButton(box) {
    let up = box.parentElement;
    for (let steps = 0; up && steps < 12; steps++, up = up.parentElement) {
      const send = [...up.querySelectorAll('[role="button"], button')].find(
        (b) => SEND.test(labelOf(b)) && shown2(b) && isAfter(b, box) && b.getAttribute("aria-disabled") !== "true"
      );
      if (send) return send;
    }
    return null;
  }
  async function writeComment(doc, text) {
    let box = commentBox(doc);
    if (!box) {
      const opener = [...mainOf2(doc).querySelectorAll('[role="button"], button')].find(
        (b) => /^(leave a comment|comment)$/i.test(labelOf(b)) && shown2(b)
      );
      opener?.click();
      await pause(1200);
      box = commentBox(doc);
    }
    if (!box) return "none";
    return typeAndSend(doc, box, text);
  }
  function messageBox(doc) {
    const label = (box) => clean(box.getAttribute("aria-label")) || clean(box.getAttribute("aria-placeholder"));
    const boxes = [...doc.querySelectorAll(WRITING)].filter(
      (b) => shown2(b) && !inTopBar(b) && MESSAGE_BOX.test(label(b)) && !COMMENT_BOX.test(label(b))
    );
    return boxes.at(-1) ?? null;
  }
  async function writeMessage(doc, text) {
    let box = messageBox(doc);
    for (let wait = 0; !box && wait < 10; wait++) {
      await pause(500);
      box = messageBox(doc);
    }
    if (!box) return "none";
    return typeAndSend(doc, box, text);
  }
  async function typeAndSend(doc, box, text) {
    if (hasWriting(box)) return "not_sent";
    box.focus();
    box.click();
    await pause(300);
    doc.execCommand("insertText", false, text);
    await pause(800);
    if (!hasWriting(box)) return "not_sent";
    const send = sendButton(box);
    if (send) send.click();
    else
      for (const type of ["keydown", "keypress", "keyup"])
        box.dispatchEvent(
          new doc.defaultView.KeyboardEvent(type, {
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            which: 13,
            bubbles: true,
            cancelable: true
          })
        );
    for (let wait = 0; wait < 20; wait++) {
      await pause(300);
      if (!hasWriting(box)) return "done";
    }
    return "not_sent";
  }

  // src/facebook/join.ts
  var pause2 = (ms) => new Promise((done) => setTimeout(done, ms));
  var WAIT_MS = 6e3;
  var LOOK_MS = 300;
  var JOIN = /^(join group|join)$/i;
  var JOINED = /^joined$/i;
  var ASKED = /^(cancel request|pending|requested)$/i;
  var SUBMIT = /^(submit|submit answers|send|done)$/i;
  var AGREE = /\bagree\b/i;
  var PLACEHOLDER = /^(write an answer|your answer|answer)\b/i;
  var mainOf3 = (doc) => doc.querySelector('[role="main"]') ?? doc.body;
  function questionsBox(doc) {
    return [...doc.querySelectorAll('[role="dialog"]')].filter(shown2).reverse().find((d) => d.querySelector('textarea, [role="textbox"], [contenteditable="true"]')) ?? null;
  }
  function answerBoxes(box) {
    return [
      ...box.querySelectorAll('textarea, [role="textbox"], [contenteditable="true"]')
    ].filter(shown2);
  }
  function questionOf(answer, box) {
    const label = clean(answer.getAttribute("aria-label"));
    if (label && !PLACEHOLDER.test(label)) return label;
    let found = null;
    const walker = box.ownerDocument.createTreeWalker(
      box,
      4
      /* NodeFilter.SHOW_TEXT */
    );
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const parent = node.parentElement;
      if (!parent || answer.contains(parent)) continue;
      if (answer.compareDocumentPosition(parent) & 4) break;
      if (parent.closest('[role="button"], button, h1, h2')) continue;
      const text = clean(node.textContent);
      if (text && !PLACEHOLDER.test(text)) found = text;
    }
    return found;
  }
  async function pressJoin(doc) {
    const buttons = [...mainOf3(doc).querySelectorAll('[role="button"], button')].filter(shown2);
    if (buttons.some((b) => JOINED.test(labelOf(b)))) return { result: "already", joined: true };
    if (buttons.some((b) => ASKED.test(labelOf(b)))) return { result: "already", joined: false };
    const join = buttons.find((b) => JOIN.test(labelOf(b)));
    if (!join) return { result: "none" };
    join.click();
    for (let waited = 0; waited < WAIT_MS; waited += LOOK_MS) {
      await pause2(LOOK_MS);
      const box = questionsBox(doc);
      if (!box) continue;
      if (box.querySelector('[role="radio"], input[type="radio"]')) return { result: "choices" };
      const questions = answerBoxes(box).map((a, i) => questionOf(a, box) ?? `Question ${i + 1}`);
      return { result: "questions", questions };
    }
    return { result: "asked" };
  }
  function typeInto(doc, box, text) {
    box.focus();
    if (box instanceof doc.defaultView.HTMLTextAreaElement || box.tagName === "INPUT") {
      const proto = Object.getPrototypeOf(box);
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (setter) setter.call(box, text);
      else box.value = text;
      box.dispatchEvent(new doc.defaultView.Event("input", { bubbles: true }));
      return;
    }
    doc.execCommand("insertText", false, text);
  }
  async function answerJoin(doc, answers) {
    const box = questionsBox(doc);
    if (!box) return "none";
    for (const [i, answer] of answerBoxes(box).entries()) {
      if (answers[i] === void 0) break;
      typeInto(doc, answer, answers[i]);
      await pause2(200);
    }
    for (const tick of box.querySelectorAll(
      '[role="checkbox"], input[type="checkbox"]'
    )) {
      const words2 = clean(tick.parentElement?.textContent) || labelOf(tick);
      const ticked = tick.getAttribute("aria-checked") === "true" || tick.checked === true;
      if (AGREE.test(words2) && !ticked) tick.click();
    }
    const submit = [...box.querySelectorAll('[role="button"], button')].find(
      (b) => SUBMIT.test(labelOf(b)) && shown2(b)
    );
    if (!submit) return "not_sent";
    submit.click();
    for (let waited = 0; waited < WAIT_MS; waited += LOOK_MS) {
      await pause2(LOOK_MS);
      if (!questionsBox(doc)) return "done";
    }
    return "not_sent";
  }

  // src/facebook/compose.ts
  var pause3 = (ms) => new Promise((done) => setTimeout(done, ms));
  var mainOf4 = (doc) => doc.querySelector('[role="main"]') ?? doc.body;
  var START = /^(write something|create a public post|start a discussion|what's on your mind|what’s on your mind)/i;
  var POST = /^post$/i;
  var PENDING = /\b(pending|waiting for (admin )?approval|admins? (will )?review)\b/i;
  var REACTED = /^see who reacted to this$/i;
  var CLOSE = /^close$/i;
  var WAIT_MS2 = 8e3;
  var LOOK_MS2 = 400;
  function composer(doc) {
    return [...doc.querySelectorAll('[role="dialog"]')].filter(shown2).reverse().find(
      (d) => d.querySelector(WRITING) && [...d.querySelectorAll('[role="button"], button')].some((b) => POST.test(labelOf(b)))
    ) ?? null;
  }
  async function writeGroupPost(doc, text) {
    let box = composer(doc);
    if (!box) {
      const start = [...mainOf4(doc).querySelectorAll('[role="button"], button')].find(
        (b) => START.test(labelOf(b)) && shown2(b)
      );
      if (!start) return "none";
      start.click();
      for (let waited = 0; !box && waited < WAIT_MS2; waited += LOOK_MS2) {
        await pause3(LOOK_MS2);
        box = composer(doc);
      }
    }
    if (!box) return "none";
    const writing = [...box.querySelectorAll(WRITING)].find(shown2);
    if (!writing) return "none";
    if (hasWriting(writing)) return "not_sent";
    writing.focus();
    writing.click();
    await pause3(300);
    doc.execCommand("insertText", false, text);
    await pause3(800);
    if (!hasWriting(writing)) return "not_sent";
    const post = [...box.querySelectorAll('[role="button"], button')].find(
      (b) => POST.test(labelOf(b)) && shown2(b) && b.getAttribute("aria-disabled") !== "true"
    );
    if (!post) return "not_sent";
    post.click();
    for (let waited = 0; waited < WAIT_MS2 * 2; waited += LOOK_MS2) {
      await pause3(LOOK_MS2);
      if (!box.isConnected || !shown2(box))
        return PENDING.test(clean(mainOf4(doc).textContent) + " " + clean(doc.body.textContent)) ? "pending" : "done";
    }
    return "not_sent";
  }
  function personIn(element, base) {
    for (const anchor of element.querySelectorAll("a[href]")) {
      const name = clean(anchor.textContent);
      if (!name || anchor.getAttribute("aria-hidden") === "true") continue;
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const profile = url ? profileFromUrl(url) : null;
      if (profile) return { name, profile };
    }
    return null;
  }
  function commentText(article) {
    const parts = [...article.querySelectorAll('div[dir="auto"], span[dir="auto"]')].filter(
      (e) => !e.closest('a, [role="button"], button') && !e.querySelector('div[dir="auto"], span[dir="auto"]') && e.closest('[role="article"]') === article
    ).map((e) => clean(e.textContent)).filter(Boolean);
    return parts.join("\n") || null;
  }
  function readComments(doc, base) {
    const post = postBoxes(mainOf4(doc))[0] ?? mainOf4(doc);
    const you = yourProfile(doc, base);
    const seen = new Set(you ? [profileKey(you)] : []);
    const found = [];
    for (const article of commentsIn(post)) {
      if (!COMMENT.test(clean(article.getAttribute("aria-label")))) continue;
      const who = personIn(article, base);
      if (!who || seen.has(profileKey(who.profile))) continue;
      seen.add(profileKey(who.profile));
      found.push({ ...who, comment: commentText(article) });
    }
    return found;
  }
  function reactionsBox(doc) {
    return [...doc.querySelectorAll('[role="dialog"]')].filter(shown2).reverse().find((d) => !d.querySelector(WRITING) && d.querySelector("a[href]")) ?? null;
  }
  async function readReactions(doc, base) {
    const post = postBoxes(mainOf4(doc))[0] ?? mainOf4(doc);
    const toolbar = [...post.querySelectorAll("[aria-label]")].find((e) => REACTED.test(labelOf(e)));
    const press3 = toolbar?.querySelector('[role="button"]') ?? toolbar;
    if (!press3) return [];
    press3.click();
    let box = null;
    for (let waited = 0; !box && waited < WAIT_MS2; waited += LOOK_MS2) {
      await pause3(LOOK_MS2);
      box = reactionsBox(doc);
    }
    if (!box) return [];
    const you = yourProfile(doc, base);
    const seen = new Set(you ? [profileKey(you)] : []);
    const found = [];
    for (const anchor of box.querySelectorAll("a[href]")) {
      const name = clean(anchor.textContent);
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const profile = url ? profileFromUrl(url) : null;
      if (!name || !profile || seen.has(profileKey(profile))) continue;
      seen.add(profileKey(profile));
      found.push({ name, profile, comment: null });
    }
    const close = [...box.querySelectorAll('[role="button"], button')].find(
      (b) => CLOSE.test(labelOf(b))
    );
    close?.click();
    return found;
  }

  // src/facebook/browse.ts
  var messengerPage = (href) => {
    const kind = classifyUrl(href).kind;
    return kind === "chat" || kind === "chats";
  };
  function chatLinks(root, base) {
    const found = [];
    for (const anchor of root.querySelectorAll("a[href]")) {
      if (inTopBar(anchor)) continue;
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const thread = url ? threadFromUrl(url) : null;
      if (thread) found.push({ anchor, id: thread.id });
    }
    return found;
  }
  function openChat(root, base, threadId) {
    if (!messengerPage(base)) return false;
    const link = chatLinks(root, base).find((l) => l.id === threadId);
    if (!link) return false;
    link.anchor.click();
    return true;
  }
  function scrolls(element) {
    const style = getComputedStyle(element);
    return element.scrollHeight > element.clientHeight + 4 && (style.overflowY === "auto" || style.overflowY === "scroll");
  }
  function scrollChats(root, base) {
    if (!messengerPage(base)) return false;
    const links = chatLinks(root, base);
    const last = links[links.length - 1]?.anchor;
    if (!last) return false;
    for (let box = last.parentElement; box; box = box.parentElement) {
      if (!scrolls(box)) continue;
      const before2 = box.scrollTop;
      box.scrollTop = before2 + Math.max(200, box.clientHeight * 0.9);
      return box.scrollTop !== before2;
    }
    const before = window.scrollY;
    last.scrollIntoView({ block: "end" });
    return window.scrollY !== before;
  }
  var groupFeedPage = (href) => classifyUrl(href).kind === "group";
  var FEED_SCROLL = 0.8;
  function scrollFeed(base) {
    if (!groupFeedPage(base)) return false;
    const before = window.scrollY;
    window.scrollBy({ top: Math.max(300, window.innerHeight * FEED_SCROLL), behavior: "smooth" });
    return document.documentElement.scrollHeight - before - window.innerHeight > 4;
  }
  var peopleListPage = (href) => {
    const kind = classifyUrl(href).kind;
    return kind === "friends" || kind === "group-members";
  };
  function scrollList(root, base) {
    if (!peopleListPage(base)) return false;
    const people = [...root.querySelectorAll("a[href]")].filter((anchor) => {
      if (inTopBar(anchor)) return false;
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      return url !== null && profileFromUrl(url) !== null;
    });
    const last = people[people.length - 1];
    for (let box = last?.parentElement ?? null; box; box = box.parentElement) {
      if (box === root.documentElement || box === root.body || !scrolls(box)) continue;
      const before2 = box.scrollTop;
      box.scrollTop = before2 + Math.max(200, box.clientHeight * FEED_SCROLL);
      return box.scrollTop !== before2;
    }
    const view = root.defaultView;
    const before = view.scrollY;
    view.scrollBy({ top: Math.max(300, view.innerHeight * FEED_SCROLL), behavior: "smooth" });
    return root.documentElement.scrollHeight - before - view.innerHeight > 4;
  }
  var groupsListPage = (href) => {
    const kind = classifyUrl(href).kind;
    return kind === "groups" || kind === "search";
  };
  function scrollPage(root, base) {
    if (!groupsListPage(base)) return false;
    const view = root.defaultView;
    const before = view.scrollY;
    view.scrollBy({ top: Math.max(300, view.innerHeight * FEED_SCROLL), behavior: "smooth" });
    return root.documentElement.scrollHeight - before - view.innerHeight > 4;
  }

  // src/facebook/looking.ts
  function lookFor(kind, on) {
    if (!on.noting) return "warnings";
    if (kind === "chat" && on.readChats) return "page";
    if (kind === "group" && on.markPosts) return "page";
    return "warnings";
  }
  var LOOK_EVERY_MS = 1e4;

  // src/facebook/outline.ts
  var KEPT = [
    "role",
    "aria-label",
    "aria-current",
    "aria-hidden",
    "aria-level",
    "aria-selected",
    "aria-expanded",
    "aria-posinset",
    "aria-setsize",
    "dir",
    "contenteditable",
    "data-pagelet",
    "data-ad-comet-preview",
    "data-ad-preview",
    "data-testid",
    "data-scope",
    "alt",
    "title",
    "placeholder",
    "href"
  ];
  var LABELS = /* @__PURE__ */ new Set(["aria-label", "alt", "title", "placeholder"]);
  var LEFT_OUT = /* @__PURE__ */ new Set(["script", "style", "noscript", "template", "link", "meta"]);
  var SHAPES = [
    /^(?:profile (?:picture|photo) of|may be an image of|may be a photo of|messages in conversation with|conversation with|seen by|more options for|actions for|see who reacted to|comment by|reply by) (.+)$/di,
    /^you(?: replied to|:) (.+)$/di,
    /^(.+?) replied to (?:you|(.+))$/di,
    /^(.+?) and \d+ others?$/di,
    /^(.+?)['’]s (?:profile|profile picture|cover photo|post|photo|story)$/di,
    /^(.+?) (?:accepted your friend request|sent you a friend request|reacted to your (?:post|comment|photo|video|message)|commented on your (?:post|photo|video)|mentioned you in a (?:comment|post)|replied to your comment|shared your post|posted in|invited you to join|is typing)(.*)$/di,
    /^(?:comment as|reply as|follow|unfollow|add friend|cancel request|message|invite) (.+)$/di
  ];
  var PLAIN = /^(\d{1,4}|\d{1,3}(,\d{3})+|\d+(\.\d+)?\s*[km]|active (now|\d+\s?[a-z]+ ago))$/i;
  function words(text) {
    const count = text.split(" ").filter(Boolean).length;
    return count === 0 ? "" : `[${count} word${count === 1 ? "" : "s"}]`;
  }
  function maskText(text) {
    const t = clean(text);
    if (isDate(t)) return "(a date)";
    if (!t || isFacebookText(t) || FETCH_WORDS.has(t.toLowerCase()) || BADGE.test(t) || sectionTitleOf(t) || PLAIN.test(t))
      return t;
    for (const shape of SHAPES) {
      const match = shape.exec(t);
      if (!match?.indices) continue;
      let out = "";
      let at = 0;
      for (let group = 1; group < match.length; group++) {
        const span = match.indices[group];
        if (!span) continue;
        out += t.slice(at, span[0]) + words(match[group] ?? "");
        at = span[1];
      }
      return out + t.slice(at);
    }
    return words(t);
  }
  function maskTitle(title) {
    const match = /^(\(\d+\+?\)\s*)?(.*?)(\s*\|\s*facebook)?$/i.exec(clean(title));
    return match ? `${match[1] ?? ""}${maskText(match[2] ?? "")}${match[3] ?? ""}` : maskText(title);
  }
  var QUERY_KEPT = /* @__PURE__ */ new Set(["sk", "notif_t", "ref", "filter"]);
  var QUERY_DROPPED = /^(__|fbclid$|mibextid$|notif_id$|paipv$|eav$|rdid$|hc_ref$|hc_location$|fref$|comment_tracking$)/;
  var Outliner = class {
    tokens = /* @__PURE__ */ new Map();
    token(value) {
      let token = this.tokens.get(value);
      if (!token) {
        token = `{${this.tokens.size + 1}}`;
        this.tokens.set(value, token);
      }
      return token;
    }
    /** A link's shape: Facebook's words in it kept, names and numbers turned into {1}, {2}… */
    maskLink(href, base) {
      if (href.startsWith("#")) return "#";
      const url = facebookUrl(href, base);
      if (!url) return /^(https?:)?\/\//i.test(href) ? "(another site)" : "(not a page)";
      const path = pathParts(url).map((part) => isFacebookPathWord(part) ? part : this.token(part.toLowerCase())).join("/");
      const query = [...url.searchParams].filter(([name]) => !QUERY_DROPPED.test(name)).map(([name, value]) => `${name}=${QUERY_KEPT.has(name) ? value : this.token(value)}`);
      const host = url.hostname === "www.facebook.com" ? "" : url.hostname;
      return `${host}/${path}${url.pathname.endsWith("/") && path ? "/" : ""}${query.length ? `?${query.join("&")}` : ""}`;
    }
    /** An element's kept attributes, as `name=value`, with labels and links hidden. */
    attributesOf(element, base) {
      const out = [];
      for (const name of KEPT) {
        const value = element.getAttribute(name);
        if (value === null) continue;
        const shown3 = name === "href" ? this.maskLink(value, base) : LABELS.has(name) ? maskText(value) : value.replace(/\d{5,}/g, (digits) => this.token(digits));
        out.push(`${name}=${JSON.stringify(shown3)}`);
      }
      return out;
    }
    /** The outline of everything under `root`, one element a line, `max` lines at most. */
    outline(root, base, max) {
      const lines = [];
      const indent = (depth) => "  ".repeat(Math.min(depth, 60));
      const walk = (element, depth) => {
        if (lines.length >= max) return;
        const tag = element.tagName.toLowerCase();
        if (LEFT_OUT.has(tag)) return;
        const attributes = this.attributesOf(element, base);
        if (element.getAttribute("role") === "banner") {
          lines.push(`${indent(depth)}${tag} ${attributes.join(" ")} (Facebook's top bar, left out)`);
          return;
        }
        const texts = [...element.childNodes].filter((node) => node.nodeType === 3).map((node) => maskText(node.nodeValue ?? "")).filter(Boolean);
        const children = [...element.children];
        if ((tag === "div" || tag === "span") && attributes.length === 0 && texts.length === 0) {
          if (children.length === 0) return;
          if (children.length === 1) return walk(children[0], depth);
        }
        const head = `${indent(depth)}${[tag, ...attributes].join(" ")}`;
        if (tag === "svg" || tag === "img" || tag === "video") {
          lines.push(head);
          return;
        }
        if (children.length === 0) {
          lines.push(
            texts.length ? `${head} ${texts.map((t) => JSON.stringify(t)).join(" ")}` : head
          );
          return;
        }
        lines.push(head);
        for (const node of element.childNodes) {
          if (node.nodeType === 1) walk(node, depth + 1);
          else if (node.nodeType === 3) {
            const text = maskText(node.nodeValue ?? "");
            if (text && lines.length < max) lines.push(`${indent(depth + 1)}${JSON.stringify(text)}`);
          }
        }
      };
      walk(root, 0);
      return lines;
    }
  };
  function counted(found) {
    const counts = [
      ["people", found.people?.length ?? 0],
      ["groups", found.groups?.length ?? 0],
      ["posts", found.posts?.length ?? 0],
      ["chats", found.chats?.length ?? 0],
      ["messages", found.chat?.messages.length ?? 0],
      ["notifications", found.notices?.length ?? 0],
      ["warnings", found.warnings.length]
    ];
    const parts = counts.filter(([, n]) => n > 0).map(([what, n]) => `${n} ${what}`);
    if (found.profile) parts.unshift("a profile");
    if (found.group) parts.unshift("a group");
    return parts.length ? parts.join(", ") : "nothing";
  }
  function outlinePage(doc, href, options = {}) {
    const outliner = new Outliner();
    const max = options.maxLines ?? 1e4;
    const body = outliner.outline(doc.body, href, max);
    const heading = [
      `HandsFreeOS Social ${options.version ?? ""} · page outline`.replace(/\s+·/, " ·"),
      `Page: ${options.found?.kind ?? "unknown"} ${outliner.maskLink(href, href)}`,
      doc.title ? `Title: ${maskTitle(doc.title)}` : null,
      options.found ? `Found: ${counted(options.found)}` : null,
      options.window ? `Window: ${options.window.width}×${options.window.height}` : null,
      "Hidden: [2 words] is something a person wrote; {1}, {2}… are the people, groups and chats links lead to.",
      body.length >= max ? `Cut at ${max} lines.` : null,
      ""
    ].filter((line) => line !== null);
    return [...heading, ...body].join("\n");
  }

  // src/facebook/tidy.ts
  function tidyPage(href) {
    return classifyUrl(href).kind === "profile";
  }

  // src/facebook/chats.ts
  function readChats(root, base) {
    const linked = collectLinked(
      root,
      base,
      (url) => {
        const thread = threadFromUrl(url);
        return thread ? { key: thread.id, value: thread } : null;
      },
      { skip: inTopBar }
    );
    const chats = [];
    for (const entry of linked) {
      const name = bestName(namesOn(entry.anchors));
      if (!name) continue;
      let preview = null;
      let when = null;
      for (const line of textLines(entry.card, 12)) {
        if (line === name) continue;
        const parts = line.split(/(?:^|\s+)·\s*/);
        const last = parts[parts.length - 1];
        if (last && isWhen(last)) {
          when ??= last;
          parts.pop();
        }
        const words2 = parts.join(" · ").trim();
        if (!words2 || preview !== null || isFacebookText(words2)) continue;
        preview = words2;
      }
      chats.push({ name, thread: entry.value, preview, when });
    }
    return chats;
  }

  // src/facebook/groups.ts
  function readGroupLinks(root, base) {
    const linked = collectLinked(
      root,
      base,
      (url) => {
        const group = groupFromUrl(url);
        return group ? { key: group.id.toLowerCase(), value: group } : null;
      },
      { skip: inTopBar }
    );
    const groups = [];
    for (const entry of linked) {
      const name = bestName(namesOn(entry.anchors));
      if (!name) continue;
      const detail = textLines(entry.card, 8).find(
        (line) => !line.startsWith(name) && !UI_WORDS.has(line.toLowerCase()) && line.length <= 120
      ) ?? null;
      groups.push({ name, group: entry.value, detail });
    }
    return groups;
  }
  function readGroupPage(root, address) {
    const heading = root.querySelector("h1");
    const name = heading ? clean(heading.textContent) || null : null;
    const lines = textLines(root, 150);
    const privacyLine = lines.find((line) => /^(public|private) group\b/i.test(line));
    const exact = lines.map((line) => /^members\s*[·•]\s*([\d.,]+)$/i.exec(line)?.[1]).find(Boolean);
    let members = exact ? parseCount(exact) : null;
    for (const line of members === null ? lines : []) {
      const match = /([\d.,]+\s*[km]?)\s+members\b/i.exec(line);
      if (match?.[1]) {
        members = parseCount(match[1]);
        break;
      }
    }
    const labels = buttonLabels(root).map((label) => label.toLowerCase());
    const asked = labels.some((label) => ASKED2.test(label));
    const joined = labels.includes("joined") ? true : asked || labels.some((label) => label === "join group" || label === "join") ? false : null;
    return {
      name,
      group: address.group,
      privacy: privacyLine ? /^public/i.test(privacyLine) ? "public" : "private" : null,
      members,
      joined,
      asked
    };
  }
  var ASKED2 = /^(cancel request|pending|requested)$/i;
  var RULES_HEADING = /^(group rules( from the admins)?|rules)$/i;
  var AFTER_RULES = /^(members|activity|recent media|group activity|featured|see all)$/i;
  var ABOUT_HEADING = /^(about( this group)?)$/i;
  var NOT_ABOUT = /^(private|public|visible|hidden|history|general)$/i;
  var LABELLED = /^(Private|Public|Visible|Hidden|History|General)\s+(?=[A-Z])/;
  var ABOUT_MOST = 30;
  var RULES_MOST = 20;
  var LINE_MOST = 300;
  var RULE_MOST = 500;
  function readGroupAbout(root) {
    const name = clean(root.querySelector("h1")?.textContent) || null;
    const lines = textLines(root, 200, '[role="button"], button, [role="tablist"], h1').filter(
      (line) => line !== name && // The heading after the rules ("Members") is a UI word too, but it says where they end.
      (AFTER_RULES.test(line) || !UI_WORDS.has(line.toLowerCase())) && !/^\d+$/.test(line)
    ).map((line) => line.replace(LABELLED, "").replace(/^\d{1,2}\s+(?=\S)/, ""));
    const rulesAt = lines.findIndex((line) => RULES_HEADING.test(line));
    const aboutLines = (rulesAt < 0 ? lines : lines.slice(0, rulesAt)).filter(
      (line) => !ABOUT_HEADING.test(line) && !NOT_ABOUT.test(line) && !AFTER_RULES.test(line) && !/^(public|private) group\b/i.test(line) && !/\bmembers?\b.*\d|\d.*\bmembers?\b/i.test(line)
    );
    const rules = [];
    if (rulesAt >= 0)
      for (const line of lines.slice(rulesAt + 1)) {
        if (AFTER_RULES.test(line)) break;
        const last = rules.length - 1;
        if (last >= 0 && !/[.!?]$/.test(rules[last]) && !rules[last].includes(": "))
          rules[last] = `${rules[last]}: ${line}`;
        else rules.push(line);
      }
    const cut = (line, most) => line.length <= most ? line : `${line.slice(0, most - 1)}…`;
    return {
      about: aboutLines.slice(0, ABOUT_MOST).map((line) => cut(line, LINE_MOST)),
      rules: rules.slice(0, RULES_MOST).map((line) => cut(line, RULE_MOST))
    };
  }

  // src/facebook/notifications.ts
  var KINDS = [
    [/\baccepted your friend request\b/i, "friend_accepted"],
    [/\b(sent you a friend request|wants? to be friends|friend requests?)\b/i, "friend_request"],
    [/\b(mentioned|tagged) you\b/i, "mention"],
    [/\b(commented on|replied to|responded to)\b/i, "comment"],
    [/\b(reacted to|likes?|liked|loves?|loved)\b.*\byour\b/i, "reaction"],
    [/\b(posted in|invited you to join|requested to join|added you to|approved your)\b/i, "group"]
  ];
  var AFTER_NAMES = /\s(accepted|sent|wants?|mentioned|tagged|commented|replied|responded|reacted|likes?|liked|loves?|loved|posted|invited|requested|added|approved|shared|updated|is|was|has|also|went|changed|joined|started)\b/i;
  var OTHERS = /^(\d+\s+)?others?$/i;
  var AROUND = /^(new|earlier|today|see previous notifications|unread|mark as read)$/i;
  function kindOf(text) {
    for (const [pattern, kind] of KINDS) if (pattern.test(text)) return kind;
    return AFTER_NAMES.test(text) ? "other" : null;
  }
  function namesIn(card, text) {
    const end = AFTER_NAMES.exec(text)?.index ?? text.length;
    const person = (name) => name.length > 0 && name.length <= 80 && !OTHERS.test(name);
    const bold = [...card.querySelectorAll("strong, b")].map((element) => clean(element.textContent)).filter((name) => {
      const at = name ? text.indexOf(name) : -1;
      return person(name) && at >= 0 && at < end;
    });
    if (bold.length > 0) return [...new Set(bold)];
    return text.slice(0, end).split(/,\s*|\s+and\s+/).map((name) => name.trim()).filter(person);
  }
  function readNotices(root, base) {
    const linked = collectLinked(root, base, (url) => ({ key: url.href, value: url }), {
      skip: inTopBar
    });
    const notices = [];
    const seen = /* @__PURE__ */ new Set();
    for (const { value: link, card } of linked) {
      const lines = textLines(card, 12).filter(
        (line) => !UI_WORDS.has(line.toLowerCase()) && !AROUND.test(line)
      );
      const when = lines.find(isWhen) ?? null;
      const text = lines.filter((line) => !isWhen(line)).join(" ");
      const kind = text.length >= 8 ? kindOf(text) : null;
      if (!kind || seen.has(text)) continue;
      seen.add(text);
      const profile = profileFromUrl(link);
      notices.push({
        kind,
        text,
        names: namesIn(card, text),
        profile,
        url: postUrlFrom(link) ?? profile?.url ?? groupFromUrl(link)?.url ?? null,
        when
      });
    }
    return notices;
  }

  // src/facebook/warnings.ts
  var WARNINGS = [
    /\btemporarily (blocked|restricted|limited)\b/i,
    /\byou can(['’]t|not) (use this feature|send|comment|post|join|react|add|message|reply)\b/i,
    /\b(misusing (this|a) feature|going too fast|too fast|too often|suspicious activity|unusual activity)\b/i,
    /\bwe limit how often\b/i,
    /\byour account (has been|was|is|got) (locked|restricted|suspended|disabled|limited)\b/i,
    /\b(confirm|verify) (your identity|it['’]s you|that this is your account)\b/i,
    /\bsecurity check\b/i,
    /\breached (the|your) limit\b/i,
    /\b(looks like spam|marked as spam|against our community standards)\b/i
  ];
  var PLACES = '[role="dialog"], [role="alertdialog"], [role="alert"], h1, h2, [role="heading"]';
  function readWarnings(doc, href) {
    const found = /* @__PURE__ */ new Set();
    const url = facebookUrl(href);
    if (url && pathParts(url)[0]?.toLowerCase() === "checkpoint")
      found.add("Facebook is asking you to check your account before you go on.");
    for (const place of doc.querySelectorAll(PLACES)) {
      if (!place.matches('[role="dialog"], [role="alertdialog"], [role="alert"]')) {
        if (place.closest('[role="article"], [role="feed"]')) continue;
      }
      for (const line of textLines(place, 40, '[role="article"], [role="feed"]')) {
        if (line.length <= 300 && WARNINGS.some((pattern) => pattern.test(line)))
          found.add(clean(line));
        if (found.size >= 5) return [...found];
      }
    }
    return [...found];
  }

  // src/facebook/page.ts
  var EXPECTED = {
    friends: "people",
    followers: "people",
    following: "people",
    "group-members": "members",
    groups: "groups",
    chats: "chats",
    chat: "messages",
    notifications: "notifications",
    feed: "posts",
    group: "posts"
  };
  var SCROLLS = /* @__PURE__ */ new Set([
    "friends",
    "followers",
    "following",
    "group-members",
    "groups",
    "group",
    "feed",
    "chats",
    "notifications",
    "search"
  ]);
  function readGroupsAnywhere(doc, main, base) {
    const places = [main, ...doc.querySelectorAll('[role="navigation"]')].filter(
      (place) => !inTopBar(place)
    );
    let best = [];
    for (const place of places) {
      const groups = readGroupLinks(place, base);
      if (groups.length > best.length) best = groups;
    }
    return best;
  }
  function readPage(doc, href, now = /* @__PURE__ */ new Date(), options = {}) {
    const address = classifyUrl(href);
    const main = doc.querySelector('[role="main"]') ?? doc.body;
    const base = href;
    const notes = [];
    let found = {};
    switch (address.kind) {
      case "profile": {
        const { profile, posts, pages } = readProfile(main, address, base, doc.title);
        found = { profile, posts, ...pages.length ? { pages } : {} };
        if (!profile.name) notes.push("Couldn’t find the name on this profile.");
        break;
      }
      case "friends": {
        const list = friendListOf(doc, href);
        const beside = listBeside(href) ? readListBeside(doc, base, list) : null;
        found = {
          people: beside ?? withRequests(readPeopleAnywhere(doc, main, base), doc.body, base, false),
          ...list ? { friendList: list } : {}
        };
        break;
      }
      case "followers":
      case "following":
        found = { people: readPeopleAnywhere(doc, main, base) };
        break;
      case "group-members":
        found = {
          group: readGroupPage(main, address),
          people: readPeople(main, base, { sections: true, after: tabsIn(main) })
        };
        break;
      case "group": {
        const url = facebookUrl(href);
        found = url && pathParts(url)[2]?.toLowerCase() === "about" ? { group: readGroupPage(main, address), about: readGroupAbout(main) } : { group: readGroupPage(main, address), posts: readPosts(main, base) };
        break;
      }
      case "groups":
        found = { groups: readGroupsAnywhere(doc, main, base) };
        break;
      case "search": {
        const url = facebookUrl(href);
        const tab = url ? pathParts(url)[1]?.toLowerCase() ?? "" : "";
        const all = !["people", "groups", "posts"].includes(tab);
        found = {
          people: all || tab === "people" ? readPeople(main, base) : [],
          groups: all || tab === "groups" ? readGroupLinks(main, base) : [],
          posts: all || tab === "posts" ? readPosts(main, base) : []
        };
        break;
      }
      case "chats":
        found = { chats: readChats(doc.body, base) };
        break;
      case "chat":
        found = { chat: readChat(doc, address, base, options), chats: readChats(doc.body, base) };
        break;
      case "notifications":
        found = { notices: readNotices(main, base) };
        break;
      case "post":
      case "feed":
        found = { posts: readPosts(main, base) };
        break;
      case "other":
        notes.push("The extension doesn’t read this kind of page yet.");
        break;
    }
    const expected = EXPECTED[address.kind];
    const counts = {
      people: found.people?.length,
      members: found.people?.length,
      groups: found.groups?.length,
      chats: found.chats?.length,
      messages: found.chat?.messages.length,
      notifications: found.notices?.length,
      posts: found.posts?.length
    };
    if (expected && !counts[expected])
      notes.push(
        `Found no ${expected} here. If the page shows some, save the page outline and send it to us so we can fix the reader.`
      );
    if (SCROLLS.has(address.kind))
      notes.push("Facebook loads more as you scroll. Scroll down to get more.");
    return {
      kind: address.kind,
      url: href,
      readAt: now.toISOString(),
      ...found,
      warnings: readWarnings(doc, href),
      notes
    };
  }

  // src/facebook/replies.ts
  var MINE2 = /^you(:|\s+(sent|replied|reacted|forwarded|unsent|called|missed|started|named|changed|added|removed|left)\b)/i;
  var NOT_A_MESSAGE = /\b(reacted|is typing|are typing|missed (a |your )?(video )?call|called you|call ended|you are now connected|you['’]re now friends|say hi to|unsent a message|named the group|left the group|joined the group|changed the)\b/i;
  var WINDOW_STEPS2 = 10;
  var keyOf = (thread) => thread && /^[0-9]{1,30}$/.test(thread.id) ? thread.id : null;
  function lastFromThem(chat, thread) {
    const last = chat.messages[chat.messages.length - 1];
    if (!last || last.from !== "them" || !chat.name) return null;
    const threadKey = keyOf(chat.thread ?? thread);
    if (!threadKey && !chat.profile) return null;
    return { name: chat.name, threadKey, profile: chat.profile, when: null };
  }
  function windowAround(conversation, main, base) {
    let up = conversation.parentElement;
    for (let steps = 0; up && steps < WINDOW_STEPS2; steps++, up = up.parentElement) {
      if (up.contains(main) || main.contains(up)) return null;
      const here2 = up;
      if ([...here2.querySelectorAll("[aria-label]")].filter(isConversation).length > 1) return null;
      const outside = [...here2.querySelectorAll("a[href]")].filter(
        (anchor) => !conversation.contains(anchor)
      );
      if (peopleLinked(outside, base).length > 0) return here2;
    }
    return null;
  }
  function threadIn(scope, base) {
    for (const anchor of scope.querySelectorAll("a[href]")) {
      const url = facebookUrl(anchor.getAttribute("href") ?? "", base);
      const thread = url ? threadFromUrl(url) : null;
      if (thread) return thread;
    }
    return null;
  }
  function readReplies(doc, href, options = {}) {
    const address = classifyUrl(href);
    const main = doc.querySelector('[role="main"]') ?? doc.body;
    const found = [];
    if (address.kind === "chats" || address.kind === "chat") {
      for (const chat of readChats(doc.body, href)) {
        const said = clean(chat.preview);
        if (!said || MINE2.test(said) || NOT_A_MESSAGE.test(said)) continue;
        const threadKey = keyOf(chat.thread);
        if (threadKey) found.push({ name: chat.name, threadKey, profile: null, when: chat.when });
      }
    }
    if (address.kind === "chat") {
      const open = lastFromThem(readChat(doc, address, href, options), address.thread);
      if (open) found.push(open);
    } else {
      for (const conversation of doc.querySelectorAll("[aria-label]")) {
        if (!isConversation(conversation) || main.contains(conversation)) continue;
        const box = windowAround(conversation, main, href);
        if (!box) continue;
        const thread = threadIn(box, href);
        const seen = lastFromThem(readChatIn(box, thread, href, options), thread);
        if (seen) found.push(seen);
      }
    }
    const byKey = /* @__PURE__ */ new Map();
    for (const s of found) {
      const key = s.threadKey ?? `${s.profile?.id ?? ""}|${s.profile?.username ?? ""}|${s.name}`;
      const had = byKey.get(key);
      byKey.set(key, had && !s.profile ? had : { ...s, when: had?.when ?? s.when });
    }
    return [...byKey.values()];
  }

  // src/messages.ts
  var NOTING_KEY = "hfos.noting";
  var READ_CHATS_KEY = "hfos.readChats";
  var MARK_POSTS_KEY = "hfos.markPosts";

  // src/content.ts
  var SETTLE_MS = 1500;
  var SAME_PRESS_MS = 1500;
  var LOOK_AGAIN_MS = 300;
  var REPLIES_EVERY_MS = 1e4;
  var AFTER_SENDING_MS = 2e4;
  var pause4 = (ms) => new Promise((done) => setTimeout(done, ms));
  async function fetchStep(ask) {
    if (ask.tidy ? !tidyPage(location.href) : !fetchPage(location.href))
      return {
        ok: false,
        error: ask.tidy ? "Facebook didn’t open their profile." : "This isn’t one of Facebook’s download pages."
      };
    const until = Date.now() + ask.waitMs;
    for (; ; ) {
      let result;
      let at;
      if (ask.type === "hfos-fetch-step") result = doStep(document, ask.step);
      else {
        const went = doPath(document, ask.steps, ask.from);
        result = "at" in went ? "done" : went.result;
        at = "at" in went ? went.at : void 0;
      }
      if (result === "done" || result === "already" || result === "stop" || Date.now() >= until)
        return { ok: true, result, at };
      await pause4(LOOK_AGAIN_MS);
    }
  }
  async function autoStep(ask) {
    const kind = classifyUrl(location.href).kind;
    if (ask.type === "hfos-like-latest") {
      if (kind !== "profile") return { ok: false, error: "Facebook didn’t open their profile." };
      const liked = await likeLatest(document, location.href, ask.profile, window);
      return { ok: true, ...liked };
    }
    if (ask.type === "hfos-message") {
      if (kind !== "chat" && kind !== "profile")
        return { ok: false, error: "Facebook didn’t open a chat with them." };
      return { ok: true, result: await writeMessage(document, ask.text) };
    }
    if (kind !== "post") return { ok: false, error: "Facebook didn’t open the post." };
    return { ok: true, result: await writeComment(document, ask.text) };
  }
  async function joinStep(ask) {
    if (classifyUrl(location.href).kind !== "group")
      return { ok: false, error: "Facebook didn’t open the group." };
    if (ask.type === "hfos-join") return { ok: true, step: await pressJoin(document) };
    return { ok: true, result: await answerJoin(document, ask.answers) };
  }
  async function groupPostStep(ask) {
    const kind = classifyUrl(location.href).kind;
    if (ask.type === "hfos-group-post") {
      if (kind !== "group") return { ok: false, error: "Facebook didn’t open the group." };
      return { ok: true, result: await writeGroupPost(document, ask.text) };
    }
    if (kind !== "post") return { ok: false, error: "Facebook didn’t open the post." };
    return {
      ok: true,
      comments: readComments(document, location.href),
      reactions: await readReactions(document, location.href)
    };
  }
  var here = globalThis;
  function matters(records) {
    return records.some(
      (record) => [...record.addedNodes, ...record.removedNodes].some(
        (node) => node.nodeType === Node.ELEMENT_NODE && ((node.textContent ?? "").trim() !== "" || node.matches("a[href]") || node.querySelector("a[href]") !== null)
      )
    );
  }
  if (!here.hfosSocialListening) {
    here.hfosSocialListening = true;
    chrome.runtime.onMessage.addListener(
      (ask, sender, respond) => {
        if (sender.id !== chrome.runtime.id) return false;
        if (ask.type === "hfos-join" || ask.type === "hfos-join-answer") {
          void joinStep(ask).then(respond);
          return true;
        }
        if (ask.type === "hfos-group-post" || ask.type === "hfos-engaged") {
          void groupPostStep(ask).then(respond);
          return true;
        }
        if (ask.type === "hfos-like-latest" || ask.type === "hfos-comment" || ask.type === "hfos-message") {
          void autoStep(ask).then(respond);
          return true;
        }
        if (ask.type === "hfos-open-chat" || ask.type === "hfos-scroll-chats" || ask.type === "hfos-scroll-feed" || ask.type === "hfos-scroll-list" || ask.type === "hfos-scroll-page") {
          const ok = ask.type === "hfos-open-chat" ? openChat(document, location.href, ask.threadId) : ask.type === "hfos-scroll-chats" ? scrollChats(document, location.href) : ask.type === "hfos-scroll-list" ? scrollList(document, location.href) : ask.type === "hfos-scroll-page" ? scrollPage(document, location.href) : scrollFeed(location.href);
          respond({ ok });
          return false;
        }
        if (ask.type === "hfos-fetch-step" || ask.type === "hfos-fetch-path") {
          void fetchStep(ask).then(respond);
          return true;
        }
        if (ask.type !== "hfos-read" && ask.type !== "hfos-outline") return false;
        try {
          const result = readPage(document, location.href);
          const outline = ask.type === "hfos-outline" ? outlinePage(document, location.href, {
            version: chrome.runtime.getManifest().version,
            found: result,
            window: { width: innerWidth, height: innerHeight }
          }) : void 0;
          respond({ ok: true, result, outline });
        } catch (error) {
          respond({ ok: false, error: error instanceof Error ? error.message : String(error) });
        }
        return false;
      }
    );
    let noting = true;
    let readChats2 = false;
    let markPosts = false;
    chrome.storage.local.get([NOTING_KEY, READ_CHATS_KEY, MARK_POSTS_KEY]).then((found) => {
      noting = found[NOTING_KEY] !== false;
      readChats2 = found[READ_CHATS_KEY] === true;
      markPosts = found[MARK_POSTS_KEY] === true;
    }).catch(() => void 0);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (NOTING_KEY in changes) noting = changes[NOTING_KEY]?.newValue !== false;
      if (READ_CHATS_KEY in changes) readChats2 = changes[READ_CHATS_KEY]?.newValue === true;
      if (MARK_POSTS_KEY in changes) markPosts = changes[MARK_POSTS_KEY]?.newValue === true;
    });
    let last = null;
    let sentAt = 0;
    const tell = (note) => {
      try {
        chrome.runtime.sendMessage(note).catch(() => void 0);
      } catch {
      }
    };
    const noted = (step) => {
      if (!step) return false;
      const now = Date.now();
      if (step.kind === "message") sentAt = now;
      const key = step.kind === "friend_request" || step.kind === "like" ? JSON.stringify([step.kind, step.to.profile, step.postUrl]) : null;
      if (!key || last?.key !== key || now - last.at > SAME_PRESS_MS)
        tell({ type: "hfos-noted", step, at: new Date(now).toISOString() });
      if (key) last = { key, at: now };
      return true;
    };
    const answered = (answer) => {
      if (!answer) return false;
      const now = Date.now();
      const key = JSON.stringify([answer.answer, answer.to.profile]);
      if (last?.key !== key || now - last.at > SAME_PRESS_MS)
        tell({ type: "hfos-answered", answered: answer, at: new Date(now).toISOString() });
      last = { key, at: now };
      return true;
    };
    const watching = (event) => noting && event.isTrusted && event.target instanceof Element ? event.target : null;
    document.addEventListener(
      "click",
      (event) => {
        const target = watching(event);
        if (!target) return;
        try {
          if (noted(stepFromClick(target, document, location.href))) return;
          if (answered(answerFromClick(target, document, location.href))) return;
          const seen = seenFromClick(target, document, location.href);
          if (seen) tell({ type: "hfos-seen", seen });
        } catch (error) {
          console.debug("HandsFreeOS Social couldn’t tell what that click was", error);
        }
      },
      true
    );
    document.addEventListener(
      "keydown",
      (event) => {
        const target = watching(event);
        if (!target || event.repeat || event.isComposing) return;
        if (event.shiftKey || event.altKey || event.ctrlKey || event.metaKey) return;
        try {
          if (event.key === "Enter" && noted(stepFromEnter(target, document, location.href))) return;
          if (event.key !== "Enter" && event.key !== " " || target.tagName === "BUTTON") return;
          if (!noted(stepFromClick(target, document, location.href)))
            answered(answerFromClick(target, document, location.href));
        } catch (error) {
          console.debug("HandsFreeOS Social couldn’t tell what that key was", error);
        }
      },
      true
    );
    let repliesTimer;
    const lookForReplies = () => {
      repliesTimer = void 0;
      if (!noting) return;
      const wait = sentAt + AFTER_SENDING_MS - Date.now();
      if (wait > 0) {
        repliesTimer = setTimeout(lookForReplies, wait);
        return;
      }
      try {
        const seen = readReplies(document, location.href);
        if (seen.length)
          tell({
            type: "hfos-replies",
            seen,
            looking: document.visibilityState === "visible" && document.hasFocus()
          });
      } catch (error) {
        console.debug("HandsFreeOS Social couldn’t look at the chats on the page", error);
      }
    };
    new MutationObserver((records) => {
      if (repliesTimer !== void 0 || !noting || !matters(records)) return;
      repliesTimer = setTimeout(lookForReplies, REPLIES_EVERY_MS);
    }).observe(document.body, { childList: true, subtree: true });
    let lookTimer;
    let lookedAt = 0;
    let lookedUrl = "";
    const look = () => {
      lookTimer = void 0;
      if (document.visibilityState !== "visible" || !document.hasFocus()) return;
      const wait = lookedAt + LOOK_EVERY_MS - Date.now();
      if (wait > 0 && location.href === lookedUrl) {
        lookTimer = setTimeout(look, wait);
        return;
      }
      lookedAt = Date.now();
      lookedUrl = location.href;
      try {
        const kind = classifyUrl(location.href).kind;
        const what = lookFor(kind, { noting, readChats: readChats2, markPosts });
        const result = what === "page" ? readPage(document, location.href) : null;
        const warnings = result ? result.warnings : readWarnings(document, location.href);
        if (warnings.length || result)
          tell({ type: "hfos-looked", url: location.href, warnings, result });
      } catch (error) {
        console.debug("HandsFreeOS Social couldn’t read the page", error);
      }
    };
    const lookSoon = () => {
      if (lookTimer === void 0) lookTimer = setTimeout(look, SETTLE_MS);
    };
    new MutationObserver((records) => {
      if (matters(records)) lookSoon();
    }).observe(document.body, { childList: true, subtree: true });
    window.addEventListener("focus", lookSoon);
    document.addEventListener("visibilitychange", lookSoon);
    lookSoon();
  }
})();
