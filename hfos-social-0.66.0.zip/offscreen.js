"use strict";
(() => {
  // ../../packages/core/src/addons/outreach/limits.ts
  var NAME_MOST = 200;
  var MESSAGE_MOST = 2e3;
  var RECENT_MESSAGES = 20;
  var TOUCH_KINDS = {
    friend_request: "Friend request",
    like: "Like",
    comment: "Comment",
    message: "Message"
  };
  var TOUCH_KIND_KEYS = Object.keys(TOUCH_KINDS);
  var DAILY_LIMITS = {
    friend_request: 20,
    first_message: 15,
    follow_up: 20,
    comment: 15,
    like: 40
  };
  var DAILY_STEPS = Object.keys(DAILY_LIMITS);
  var TIDY_LIMITS = { cancel_request: 30, unfriend: 20 };
  var TIDY_KIND_KEYS = Object.keys(TIDY_LIMITS);
  var FRIEND_STATES = {
    friends: "Friends",
    request_sent: "Request sent",
    request_received: "Asked to be friends",
    declined: "Request deleted",
    not_friends: "Not friends"
  };
  var FRIEND_STATE_KEYS = Object.keys(FRIEND_STATES);
  var FRIEND_ANSWERS = {
    confirm: "Confirmed",
    delete: "Deleted request"
  };
  var FRIEND_ANSWER_KEYS = Object.keys(FRIEND_ANSWERS);
  var FRIENDS_SAVE_MOST = 500;
  var DOWNLOAD_PEOPLE_MOST = 600;
  var DOWNLOAD_CHATS_MOST = 400;
  var DOWNLOAD_PART_BYTES = 2e5;

  // ../../packages/core/src/addons/outreach/download-read.ts
  var DownloadError = class extends Error {
    constructor(rule) {
      super(DOWNLOAD_PROBLEMS[rule]);
      this.rule = rule;
      this.name = "DownloadError";
    }
    rule;
  };
  var DOWNLOAD_PROBLEMS = {
    not_zip: "That isn’t one of Facebook’s zip files. Pick the files Facebook gave you, the ones ending in .zip.",
    cut_short: "That file stops partway, so it didn’t finish downloading. Download it from Facebook again and pick the new one.",
    locked: "That zip has a password on it. Pick the file just as Facebook gave it to you.",
    packing: "That zip is packed in a way this page can’t open. Pick the file just as Facebook gave it to you.",
    html: "That file is in HTML, which can’t be read here. Ask Facebook for your information again with Format set to JSON, then pick the new file.",
    nothing: "There are no friends, requests or chats in those files. Pick the files from Download your information, and the chat backup if you have it."
  };
  var END = 101010256;
  var BIG_END_AT = 117853008;
  var BIG_END = 101075792;
  var LISTED = 33639248;
  var HEADER = 67324752;
  var WHOLE = 4294967295;
  async function partOf(file, from, to) {
    return new DataView(await file.slice(from, to).arrayBuffer());
  }
  function zipTime(date, time) {
    const month = date >> 5 & 15;
    const day = date & 31;
    if (!date || month < 1 || month > 12 || day < 1) return null;
    return new Date(
      Date.UTC(1980 + (date >> 9), month - 1, day, time >> 11, time >> 5 & 63, (time & 31) * 2)
    );
  }
  async function zipEntries(file) {
    const tailLength = Math.min(file.size, 22 + 65535 + 20);
    const tail = await partOf(file, file.size - tailLength, file.size);
    let end = -1;
    for (let i = tailLength - 22; i >= 0; i--) {
      if (tail.getUint32(i, true) === END) {
        end = i;
        break;
      }
    }
    if (end < 0) {
      const start = file.size >= 4 ? await partOf(file, 0, 4) : null;
      throw new DownloadError(start?.getUint32(0, true) === HEADER ? "cut_short" : "not_zip");
    }
    let count = tail.getUint16(end + 10, true);
    let listSize = tail.getUint32(end + 12, true);
    let listAt = tail.getUint32(end + 16, true);
    if (end >= 20 && tail.getUint32(end - 20, true) === BIG_END_AT) {
      const at = Number(tail.getBigUint64(end - 12, true));
      if (at + 56 > file.size) throw new DownloadError("cut_short");
      const big = await partOf(file, at, at + 56);
      if (big.getUint32(0, true) === BIG_END) {
        count = Number(big.getBigUint64(32, true));
        listSize = Number(big.getBigUint64(40, true));
        listAt = Number(big.getBigUint64(48, true));
      }
    }
    if (listAt + listSize > file.size) throw new DownloadError("cut_short");
    const list = await partOf(file, listAt, listAt + listSize);
    const text = new TextDecoder("utf-8");
    const entries = [];
    let p = 0;
    while (entries.length < count && p + 46 <= list.byteLength && list.getUint32(p, true) === LISTED) {
      const flags = list.getUint16(p + 8, true);
      let packed = list.getUint32(p + 20, true);
      const size = list.getUint32(p + 24, true);
      const nameLength = list.getUint16(p + 28, true);
      const extraLength = list.getUint16(p + 30, true);
      const commentLength = list.getUint16(p + 32, true);
      let at = list.getUint32(p + 42, true);
      let changed = zipTime(list.getUint16(p + 14, true), list.getUint16(p + 12, true));
      const name = text.decode(new Uint8Array(list.buffer, list.byteOffset + p + 46, nameLength));
      const extraEnd = p + 46 + nameLength + extraLength;
      for (let e = p + 46 + nameLength; e + 4 <= extraEnd; ) {
        const id = list.getUint16(e, true);
        const length = list.getUint16(e + 2, true);
        if (id === 1) {
          let q = e + 4;
          if (size === WHOLE) q += 8;
          if (packed === WHOLE) {
            packed = Number(list.getBigUint64(q, true));
            q += 8;
          }
          if (at === WHOLE) at = Number(list.getBigUint64(q, true));
        } else if (id === 21589 && length >= 5 && list.getUint8(e + 4) & 1) {
          changed = new Date(list.getUint32(e + 5, true) * 1e3);
        }
        e += 4 + length;
      }
      entries.push({
        name,
        method: list.getUint16(p + 10, true),
        packed,
        at,
        encrypted: (flags & 1) === 1,
        changed
      });
      p = extraEnd + commentLength;
    }
    return entries;
  }
  async function zipEntryBytes(file, entry) {
    if (entry.encrypted) throw new DownloadError("locked");
    if (entry.at + 30 > file.size) throw new DownloadError("cut_short");
    const header = await partOf(file, entry.at, entry.at + 30);
    if (header.getUint32(0, true) !== HEADER) throw new DownloadError("cut_short");
    const from = entry.at + 30 + header.getUint16(26, true) + header.getUint16(28, true);
    if (from + entry.packed > file.size) throw new DownloadError("cut_short");
    const packed = file.slice(from, from + entry.packed);
    if (entry.method === 0) return new Uint8Array(await packed.arrayBuffer());
    if (entry.method !== 8) throw new DownloadError("packing");
    const unpacked = packed.stream().pipeThrough(new DecompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(unpacked).arrayBuffer());
  }
  var DOWNLOAD_LISTS = {
    friends: "Friends",
    request_sent: "Requests you sent",
    request_received: "Requests you’ve got",
    removed: "Friends you removed",
    declined: "Requests you deleted",
    followers: "Your followers",
    following: "People you follow"
  };
  var DOWNLOAD_LIST_KEYS = Object.keys(DOWNLOAD_LISTS);
  var LIST_KEYS = /* @__PURE__ */ new Map([
    ["friends_v2", "friends"],
    ["friends", "friends"],
    ["sent_requests_v2", "request_sent"],
    ["sent_requests", "request_sent"],
    ["received_requests_v2", "request_received"],
    ["received_requests", "request_received"],
    ["deleted_friends_v2", "removed"],
    ["deleted_friends", "removed"],
    ["removed_friends_v2", "removed"],
    ["removed_friends", "removed"],
    ["rejected_requests_v2", "declined"],
    ["rejected_requests", "declined"],
    ["followers_v3", "followers"],
    ["followers_v2", "followers"],
    ["followers", "followers"],
    ["following_v3", "following"],
    ["following_v2", "following"],
    ["following", "following"]
  ]);
  var LIST_FILES = /* @__PURE__ */ new Map([
    ["your_friends.json", "friends"],
    ["friends.json", "friends"],
    ["sent_friend_requests.json", "request_sent"],
    ["received_friend_requests.json", "request_received"],
    ["friend_requests_received.json", "request_received"],
    ["removed_friends.json", "removed"],
    ["rejected_friend_requests.json", "declined"],
    ["people_who_followed_you.json", "followers"],
    ["followers.json", "followers"],
    ["who_you've_followed.json", "following"],
    ["who_you_follow.json", "following"],
    ["following.json", "following"]
  ]);
  var LIST_FOLDERS = /(^|\/)(connections|friends|followers|following|friends_and_followers)\//;
  var strictText = new TextDecoder("utf-8", { fatal: true });
  function facebookText(text) {
    let high = false;
    for (let i = 0; i < text.length; i++) {
      const c = text.charCodeAt(i);
      if (c > 255) return text;
      if (c > 127) high = true;
    }
    if (!high) return text;
    try {
      return strictText.decode(Uint8Array.from(text, (c) => c.charCodeAt(0)));
    } catch {
      return text;
    }
  }
  function nameKey(name) {
    return name.normalize("NFC").trim().replace(/\s+/g, " ").toLowerCase();
  }
  var FIRST_DAY = Date.UTC(2004, 0, 1);
  function msOf(value) {
    const n = typeof value === "string" && /^\d{9,13}$/.test(value) ? Number(value) : value;
    if (typeof n !== "number" || !Number.isFinite(n)) return null;
    const ms = n < 1e11 ? n * 1e3 : n;
    return ms >= FIRST_DAY && ms < Date.now() + 864e5 ? Math.round(ms) : null;
  }
  var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  var GONE = /^(facebook|instagram|messenger) user$/i;
  var cleanName = (raw) => {
    if (typeof raw !== "string") return null;
    const name = facebookText(raw).trim().replace(/\s+/g, " ");
    return name && name.length <= NAME_MOST && !GONE.test(name) ? name : null;
  };
  function entryOf(item) {
    if (!isRecord(item)) return null;
    let name = cleanName(item.name) ?? cleanName(item.title);
    let ms = msOf(item.timestamp ?? item.creation_timestamp);
    if (Array.isArray(item.label_values)) {
      for (const field of item.label_values) {
        if (!isRecord(field)) continue;
        const label = typeof field.label === "string" ? field.label.toLowerCase() : "";
        if (!name && label.includes("name")) name = cleanName(field.value);
        ms ??= msOf(field.timestamp_value);
      }
    }
    if (!name && Array.isArray(item.string_list_data) && isRecord(item.string_list_data[0])) {
      name = cleanName(item.string_list_data[0].value);
      ms ??= msOf(item.string_list_data[0].timestamp);
    }
    return name ? { name, at: ms === null ? null : new Date(ms).toISOString() } : null;
  }
  function listIn(path, data) {
    const file = (path.split("/").pop() ?? "").toLowerCase();
    const byFile = LIST_FILES.get(file);
    if (!LIST_FOLDERS.test(path) && !byFile) return null;
    let found = null;
    if (Array.isArray(data)) found = byFile ? { list: byFile, items: data } : null;
    else if (isRecord(data)) {
      for (const [key, value] of Object.entries(data)) {
        const list2 = LIST_KEYS.get(key);
        if (list2 && Array.isArray(value)) {
          found = { list: list2, items: value };
          break;
        }
      }
      const lists = Object.values(data).filter(Array.isArray);
      if (!found && byFile && lists.length === 1) found = { list: byFile, items: lists[0] };
    }
    if (!found) return null;
    const { list, items } = found;
    return items.flatMap((item) => {
      const entry = entryOf(item);
      return entry ? [{ list, ...entry }] : [];
    });
  }
  function withoutWords(m) {
    if (Array.isArray(m.photos)) return "(a photo)";
    if (Array.isArray(m.videos)) return "(a video)";
    if (Array.isArray(m.audio_files)) return "(a voice message)";
    if (Array.isArray(m.gifs)) return "(a GIF)";
    if (Array.isArray(m.files)) return "(a file)";
    if (isRecord(m.sticker)) return "(a sticker)";
    if (isRecord(m.share)) return "(a link)";
    return null;
  }
  function wordsOf(m) {
    const raw = m.content ?? m.text;
    const words2 = typeof raw === "string" ? facebookText(raw).trim() : "";
    if (!words2) return withoutWords(m);
    return words2.length > MESSAGE_MOST ? `${words2.slice(0, MESSAGE_MOST - 1)}…` : words2;
  }
  function chatIn(data) {
    if (!isRecord(data) || !Array.isArray(data.participants) || !Array.isArray(data.messages))
      return null;
    const people = data.participants.flatMap((p) => {
      const name = cleanName(isRecord(p) ? p.name : p);
      return name ? [name] : [];
    });
    const messages = data.messages.flatMap((m) => {
      if (!isRecord(m)) return [];
      const at = msOf(m.timestamp_ms ?? m.timestampMs ?? m.timestamp);
      if (at === null) return [];
      const sender = m.sender_name ?? m.senderName ?? m.sender;
      return [{ from: cleanName(isRecord(sender) ? sender.name : sender), at, m }];
    }).sort((a, b) => a.at - b.at);
    const from = messages.length - RECENT_MESSAGES;
    return {
      people,
      messages: messages.map(({ from: who, at, m }, i) => {
        const text = i >= from ? wordsOf(m) : null;
        return text ? { from: who, at, text } : { from: who, at };
      })
    };
  }
  function ownerIn(data) {
    if (!isRecord(data)) return null;
    const profile = isRecord(data.profile_v2) ? data.profile_v2 : isRecord(data.profile) ? data.profile : null;
    const name = profile && isRecord(profile.name) ? profile.name.full_name : profile?.name;
    return cleanName(name);
  }
  function chatsByPerson(chats, owner) {
    const pairs = chats.filter((c) => c.people.length === 2 && c.messages.length);
    let me = owner ? nameKey(owner) : null;
    if (!me || !pairs.some((c) => c.people.some((p) => nameKey(p) === me))) {
      const seen = /* @__PURE__ */ new Map();
      for (const c of pairs)
        for (const key of new Set(c.people.map(nameKey))) seen.set(key, (seen.get(key) ?? 0) + 1);
      const [top, second] = [...seen].sort((a, b) => b[1] - a[1]);
      me = top && top[1] > 1 && (!second || top[1] > second[1]) ? top[0] : null;
    }
    if (!me) return [];
    const byPerson = /* @__PURE__ */ new Map();
    for (const c of pairs) {
      const other = c.people.find((p) => nameKey(p) !== me);
      if (!other || !c.people.some((p) => nameKey(p) === me)) continue;
      const key = nameKey(other);
      const had = byPerson.get(key) ?? {
        name: other,
        first: Infinity,
        last: -Infinity,
        messages: 0,
        lastFromMe: false,
        recent: []
      };
      for (const m of c.messages) {
        const mine = m.from !== null && nameKey(m.from) === me;
        had.first = Math.min(had.first, m.at);
        if (m.at >= had.last) {
          had.last = m.at;
          had.lastFromMe = mine;
        }
        had.messages++;
        if (m.text) had.recent.push({ fromMe: mine, text: m.text, at: new Date(m.at).toISOString() });
      }
      had.recent = had.recent.sort((a, b) => a.at.localeCompare(b.at)).slice(-RECENT_MESSAGES);
      byPerson.set(key, had);
    }
    return [...byPerson.values()].map((c) => ({
      name: c.name,
      firstAt: new Date(c.first).toISOString(),
      lastAt: new Date(c.last).toISOString(),
      messages: c.messages,
      lastFromMe: c.lastFromMe,
      recent: c.recent
    }));
  }
  var CHAT_PLACES = /(^|\/)(messages?|inbox|e2ee[a-z_]*|archived_threads|filtered_threads|message_requests)\//;
  var DOWNLOAD_FOLDERS = /^(connections|your_facebook_activity|personal_information|logged_information)\//;
  var PROFILE_FILE = /(^|\/)profile_information\.json$/;
  var BIGGEST_JSON = 2e8;
  async function readDownload(files, progress) {
    const zips = await Promise.all(
      files.map(async (file) => ({ file, entries: await zipEntries(file) }))
    );
    const toRead = [];
    let html = 0;
    let locked = 0;
    let latest = 0;
    for (const { file, entries } of zips) {
      const backup = !entries.some((e) => DOWNLOAD_FOLDERS.test(e.name));
      for (const entry of entries) {
        if (entry.changed) latest = Math.max(latest, entry.changed.getTime());
        const path = entry.name;
        if (/\.html?$/i.test(path)) html++;
        if (!/\.json$/i.test(path)) continue;
        if (entry.encrypted) {
          locked++;
          continue;
        }
        const name = (path.split("/").pop() ?? "").toLowerCase();
        if (PROFILE_FILE.test(path)) toRead.push({ file, entry, kind: "profile" });
        else if (LIST_FOLDERS.test(path) || LIST_FILES.has(name))
          toRead.push({ file, entry, kind: "list" });
        else if (backup || CHAT_PLACES.test(path)) toRead.push({ file, entry, kind: "chat" });
      }
    }
    if (!toRead.length) throw new DownloadError(locked ? "locked" : html ? "html" : "nothing");
    const text = new TextDecoder("utf-8");
    const people = /* @__PURE__ */ new Map();
    const chats = [];
    let owner = null;
    let read = 0;
    let unread = 0;
    for (const [i, { file, entry, kind }] of toRead.entries()) {
      await progress?.(i, toRead.length);
      let data;
      try {
        if (entry.packed > BIGGEST_JSON) throw new Error("too big");
        data = JSON.parse(text.decode(await zipEntryBytes(file, entry)));
        read++;
      } catch (e) {
        if (e instanceof DownloadError && e.rule === "cut_short") throw e;
        unread++;
        continue;
      }
      if (kind === "profile") owner ??= ownerIn(data);
      else if (kind === "list") {
        for (const p of listIn(entry.name, data) ?? [])
          people.set(`${p.list}
${nameKey(p.name)}
${p.at ?? ""}`, p);
      } else {
        const chat = chatIn(data);
        if (chat) chats.push(chat);
      }
    }
    await progress?.(toRead.length, toRead.length);
    const byPerson = chatsByPerson(chats, owner);
    if (!people.size && !byPerson.length) throw new DownloadError(html ? "html" : "nothing");
    for (const p of people.values()) if (p.at) latest = Math.max(latest, Date.parse(p.at));
    for (const c of byPerson) latest = Math.max(latest, Date.parse(c.lastAt));
    return {
      madeAt: new Date(Math.min(latest || Date.now(), Date.now())).toISOString(),
      people: [...people.values()],
      chats: byPerson,
      read,
      unread
    };
  }
  function downloadParts(read) {
    const parts = [];
    const size = new TextEncoder();
    let part = { people: [], chats: [] };
    let bytes = 0;
    const add = (kind, item, most) => {
      const length = size.encode(JSON.stringify(item)).length + 1;
      if (part[kind].length >= most || bytes + length > DOWNLOAD_PART_BYTES) {
        parts.push(part);
        part = { people: [], chats: [] };
        bytes = 0;
      }
      part[kind].push(item);
      bytes += length;
    };
    for (const p of read.people) add("people", p, DOWNLOAD_PEOPLE_MOST);
    for (const c of read.chats) add("chats", c, DOWNLOAD_CHATS_MOST);
    if (part.people.length || part.chats.length || !parts.length) parts.push(part);
    return parts;
  }

  // ../../packages/core/src/addons/outreach/linkedin-export.ts
  var LINKEDIN_FILE_PROBLEMS = {
    not_zip: "That isn’t LinkedIn’s zip file. Ask for Download my file on LinkedIn again, then ask for Bring it in.",
    cut_short: "Your LinkedIn file stops partway, so it didn’t finish downloading. Ask for Download my file on LinkedIn again, then ask for Bring it in.",
    locked: "Your LinkedIn zip has a password on it. Download it again just as LinkedIn gives it, from Get a copy of your data in LinkedIn’s Settings, then ask again.",
    packing: "Your LinkedIn zip is packed in a way the extension can’t open. Download it again just as LinkedIn gives it, from Get a copy of your data in LinkedIn’s Settings, then ask again.",
    html: "That file can’t be read. Download your LinkedIn file again from Get a copy of your data in LinkedIn’s Settings, then ask again.",
    nothing: "There are no connections, invitations or messages in your LinkedIn file. Ask for your LinkedIn file again (it ticks Connections, Invitations and Messages), download it once LinkedIn emails you, then ask again."
  };
  function csvRows(text) {
    const rows = [];
    let row = [];
    let field = "";
    let quoted = false;
    const s = text.replace(/^\uFEFF/, "");
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (quoted) {
        if (c === '"' && s[i + 1] === '"') {
          field += '"';
          i++;
        } else if (c === '"') quoted = false;
        else field += c;
      } else if (c === '"' && field === "") quoted = true;
      else if (c === ",") {
        row.push(field);
        field = "";
      } else if (c === "\n" || c === "\r") {
        if (c === "\r" && s[i + 1] === "\n") i++;
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
      } else field += c;
    }
    if (field !== "" || row.length) {
      row.push(field);
      rows.push(row);
    }
    return rows;
  }
  function table(text, needed) {
    const rows = csvRows(text);
    const at = rows.findIndex((r) => {
      const names = new Set(r.map((c) => c.trim().toLowerCase()));
      return needed.every((n) => names.has(n));
    });
    if (at < 0) return null;
    const header = rows[at].map((c) => c.trim().toLowerCase());
    return rows.slice(at + 1).filter((r) => r.some((c) => c.trim())).map((r) => new Map(header.map((h, i) => [h, (r[i] ?? "").trim()])));
  }
  var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var FIRST_DAY2 = Date.UTC(2003, 4, 1);
  function linkedInTime(raw) {
    const text = raw.trim();
    let ms = null;
    const dayMonth = /^(\d{1,2}) ([A-Za-z]{3})[a-z]* (\d{4})$/.exec(text);
    const us = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4}),? (\d{1,2}):(\d{2})(?::(\d{2}))? ?([AaPp][Mm])?$/.exec(text);
    const iso = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?(?: ?(?:UTC|Z))?$/.exec(
      text
    );
    if (dayMonth) {
      const month = MONTHS.indexOf(dayMonth[2].toLowerCase());
      if (month >= 0) ms = Date.UTC(Number(dayMonth[3]), month, Number(dayMonth[1]));
    } else if (us) {
      const year = Number(us[3]) < 100 ? 2e3 + Number(us[3]) : Number(us[3]);
      let hour = Number(us[4]) % 12;
      if (us[7]?.toLowerCase() === "pm") hour += 12;
      if (!us[7]) hour = Number(us[4]);
      ms = Date.UTC(year, Number(us[1]) - 1, Number(us[2]), hour, Number(us[5]), Number(us[6] ?? 0));
    } else if (iso) {
      ms = Date.UTC(
        Number(iso[1]),
        Number(iso[2]) - 1,
        Number(iso[3]),
        Number(iso[4]),
        Number(iso[5]),
        Number(iso[6] ?? 0)
      );
    }
    return ms !== null && Number.isFinite(ms) && ms >= FIRST_DAY2 && ms <= Date.now() + 864e5 ? new Date(ms).toISOString() : null;
  }
  function linkedInProfileUrl(raw) {
    const m = /^(?:https?:\/\/)?(?:[a-z]{2,3}\.|www\.)?linkedin\.com\/in\/([A-Za-z0-9%_-]{1,100})\/?(?:[?#].*)?$/i.exec(
      raw.trim()
    );
    return m ? `https://www.linkedin.com/in/${m[1]}/` : null;
  }
  var cleanName2 = (raw) => {
    const name = (raw ?? "").trim().replace(/\s+/g, " ");
    return name && name.length <= NAME_MOST ? name : null;
  };
  function connectionsIn(text) {
    const rows = table(text, ["first name", "last name", "url"]);
    if (!rows) return null;
    return rows.flatMap((r) => {
      const name = cleanName2(`${r.get("first name") ?? ""} ${r.get("last name") ?? ""}`);
      return name ? [
        {
          name,
          url: linkedInProfileUrl(r.get("url") ?? ""),
          at: linkedInTime(r.get("connected on") ?? "")
        }
      ] : [];
    });
  }
  function invitationsIn(text) {
    const rows = table(text, ["from", "to", "direction"]);
    if (!rows) return null;
    return rows.flatMap((r) => {
      const way = (r.get("direction") ?? "").toLowerCase();
      const direction = way.startsWith("out") ? "sent" : way.startsWith("in") ? "received" : null;
      if (!direction) return [];
      const name = cleanName2(direction === "sent" ? r.get("to") : r.get("from"));
      const url = linkedInProfileUrl(
        (direction === "sent" ? r.get("inviteeprofileurl") : r.get("inviterprofileurl")) ?? ""
      );
      return name ? [{ name, url, at: linkedInTime(r.get("sent at") ?? ""), direction }] : [];
    });
  }
  function ownerOf(text) {
    const [row] = table(text, ["first name", "last name"]) ?? [];
    return row ? cleanName2(`${row.get("first name") ?? ""} ${row.get("last name") ?? ""}`) : null;
  }
  var words = (raw) => raw.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "’").replace(/[ \t]+/g, " ").trim().slice(0, MESSAGE_MOST);
  function linkedInChatsIn(text, owner) {
    const rows = table(text, ["conversation id", "from", "to", "date"]);
    if (!rows) return null;
    const byConversation = /* @__PURE__ */ new Map();
    for (const r of rows) {
      if ((r.get("folder") ?? "").toLowerCase().includes("spam")) continue;
      const at = linkedInTime(r.get("date") ?? "");
      const from = cleanName2(r.get("from"));
      if (!at || !from) continue;
      const to = (r.get("to") ?? "").split(",").map((n) => cleanName2(n)).filter((n) => n !== null);
      const id = r.get("conversation id") ?? "";
      const lines = byConversation.get(id) ?? [];
      lines.push({
        from,
        to,
        fromUrl: r.get("sender profile url") ?? "",
        toUrl: r.get("recipient profile urls") ?? "",
        at,
        text: words(r.get("content") ?? "")
      });
      byConversation.set(id, lines);
    }
    const pairs = [...byConversation.values()].filter(
      (lines) => new Set(lines.flatMap((l) => [l.from, ...l.to]).map(nameKey)).size === 2
    );
    let me = owner ? nameKey(owner) : null;
    if (!me || !pairs.some((lines) => lines.some((l) => nameKey(l.from) === me))) {
      const seen = /* @__PURE__ */ new Map();
      for (const lines of pairs)
        for (const key of new Set(lines.flatMap((l) => [l.from, ...l.to]).map(nameKey)))
          seen.set(key, (seen.get(key) ?? 0) + 1);
      const [top, second] = [...seen].sort((a, b) => b[1] - a[1]);
      me = top && top[1] > 1 && (!second || top[1] > second[1]) ? top[0] : null;
    }
    if (!me) return [];
    const chats = [];
    for (const lines of pairs) {
      const sorted = [...lines].sort((a, b) => a.at.localeCompare(b.at));
      const theirs = sorted.find((l) => nameKey(l.from) !== me);
      const mine = sorted.find((l) => nameKey(l.from) === me);
      const other = theirs?.from ?? mine?.to.find((n) => nameKey(n) !== me);
      if (!other) continue;
      const url = linkedInProfileUrl(theirs?.fromUrl ?? "") ?? (mine ? linkedInProfileUrl(mine.toUrl.split(",")[0] ?? "") : null);
      const recent = sorted.filter((l) => l.text).slice(-RECENT_MESSAGES).map((l) => ({ fromMe: nameKey(l.from) === me, text: l.text, at: l.at }));
      const last = sorted.at(-1);
      chats.push({
        name: other,
        url,
        firstAt: sorted[0].at,
        lastAt: last.at,
        messages: sorted.length,
        lastFromMe: nameKey(last.from) === me,
        recent
      });
    }
    return chats;
  }
  var FILES = {
    connections: /(^|\/)connections\.csv$/i,
    invitations: /(^|\/)invitations\.csv$/i,
    messages: /(^|\/)messages\.csv$/i,
    profile: /(^|\/)profile\.csv$/i
  };
  async function readLinkedInExport(files, progress) {
    const toRead = [];
    let latest = 0;
    let locked = 0;
    for (const file of files)
      for (const entry of await zipEntries(file)) {
        if (entry.changed) latest = Math.max(latest, entry.changed.getTime());
        const kind = Object.keys(FILES).find((k) => FILES[k].test(entry.name));
        if (!kind) continue;
        if (entry.encrypted) locked++;
        else toRead.push({ file, entry, kind });
      }
    if (!toRead.length) throw new DownloadError(locked ? "locked" : "nothing");
    const text = new TextDecoder("utf-8");
    const found = {};
    let read = 0;
    let unread = 0;
    for (const [i, { file, entry, kind }] of toRead.entries()) {
      await progress?.(i, toRead.length);
      try {
        (found[kind] ??= []).push(text.decode(await zipEntryBytes(file, entry)));
        read++;
      } catch (e) {
        if (e instanceof DownloadError && e.rule === "cut_short") throw e;
        unread++;
      }
    }
    await progress?.(toRead.length, toRead.length);
    const owner = (found.profile ?? []).map(ownerOf).find((n) => n !== null) ?? null;
    const connections = (found.connections ?? []).flatMap((t) => connectionsIn(t) ?? []);
    const invitations = (found.invitations ?? []).flatMap((t) => invitationsIn(t) ?? []);
    const chats = (found.messages ?? []).flatMap((t) => linkedInChatsIn(t, owner) ?? []);
    if (!connections.length && !invitations.length && !chats.length)
      throw new DownloadError("nothing");
    for (const p of [...connections, ...invitations])
      if (p.at) latest = Math.max(latest, Date.parse(p.at));
    for (const c of chats) latest = Math.max(latest, Date.parse(c.lastAt));
    return {
      madeAt: new Date(Math.min(latest || Date.now(), Date.now())).toISOString(),
      connections,
      invitations,
      chats,
      read,
      unread
    };
  }

  // src/networks/linkedin/data.ts
  var DATA_PAGE = "https://www.linkedin.com/mypreferences/d/download-my-data";
  var PREPARING = [
    "being prepared",
    "preparing your archive",
    "preparing your data",
    "request is in progress"
  ];
  var press = (words2, says, more = {}) => ({ action: "press", words: words2, says, ...more });
  var LINKEDIN_FILE_PLANS = {
    request: {
      job: "request",
      url: DATA_PAGE,
      mode: "steps",
      steps: [
        {
          action: "stopIf",
          words: PREPARING,
          optional: true,
          says: "LinkedIn is already making your copy. It emails you when it’s ready; then ask for Download my file."
        },
        {
          action: "pick",
          words: ["Want something in particular", "Select the data files"],
          anywhere: true,
          says: "Pick “Want something in particular?”."
        },
        { action: "tick", words: ["Connections"], exact: true, says: "Tick “Connections”." },
        { action: "tick", words: ["Invitations"], exact: true, says: "Tick “Invitations”." },
        { action: "tick", words: ["Messages"], exact: true, says: "Tick “Messages”." },
        {
          action: "tick",
          words: ["Profile"],
          exact: true,
          optional: true,
          says: "Tick “Profile”."
        },
        press(["Request archive"], "Press “Request archive”.", { exact: true, buttonsOnly: true }),
        {
          action: "waitFor",
          words: PREPARING,
          says: "If LinkedIn asks for your password, type it and press Done."
        }
      ]
    },
    download: {
      job: "download",
      url: DATA_PAGE,
      mode: "steps",
      steps: [
        {
          action: "stopIf",
          words: PREPARING,
          optional: true,
          says: "LinkedIn is still making your copy. It emails you when it’s ready; then ask for Download my file again."
        },
        press(["Download archive"], "Press “Download archive”.", { exact: true })
      ]
    }
  };
  var DATA_WORDS = new Set(
    [
      ...Object.values(LINKEDIN_FILE_PLANS).flatMap((plan) => plan.steps.flatMap((s) => s.words)),
      "Get a copy of your data",
      "Download your data",
      "Data privacy",
      "Want something in particular? Select the data files you’re most interested in.",
      "Want something in particular? Select the data files you're most interested in.",
      "Articles",
      "Imported Contacts",
      "Recommendations",
      "Registration",
      "Rich Media",
      "Learning",
      "Enter your password",
      "Password",
      "Done",
      "Cancel"
    ].map((word) => word.toLowerCase())
  );

  // src/networks/linkedin/urls.ts
  var LINKEDIN = "https://www.linkedin.com";
  var HOSTS = /* @__PURE__ */ new Set(["linkedin.com", "www.linkedin.com"]);
  var USERNAME = /^[A-Za-z0-9%_-]{1,100}$/;
  var MEMBER_ID = /^AC[ow]AA[A-Za-z0-9_-]{6,59}$/;
  var THREAD_KEY = /^[A-Za-z0-9._=+-]{1,128}$/;
  var POST_URN = /^urn:li:(activity|share|ugcPost):(\d{6,25})$/;
  var POST_SLUG = /-(activity|share|ugcPost)-(\d{6,25})(?:-|$)/;
  function linkedinUrl(href, base = LINKEDIN) {
    let url;
    try {
      url = new URL(href, base);
    } catch {
      return null;
    }
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    return HOSTS.has(url.hostname.toLowerCase()) ? url : null;
  }
  function pathParts(url) {
    return url.pathname.split("/").filter(Boolean);
  }
  function decoded(part) {
    try {
      return decodeURIComponent(part);
    } catch {
      return part;
    }
  }
  function usernameOf(part) {
    const name = part.replace(/%[0-9a-f]{2}/gi, (escape) => escape.toUpperCase());
    return USERNAME.test(name) && name.toLowerCase() !== "me" ? name : null;
  }
  function memberIdIn(value) {
    const id = value ? decoded(value).trim().split(":").pop() : null;
    return id && MEMBER_ID.test(id) ? id : null;
  }
  function memberIdFrom(url) {
    for (const key of ["miniProfileUrn", "profileUrn", "recipient"]) {
      const id = memberIdIn(url.searchParams.get(key));
      if (id) return id;
    }
    for (const key of ["connectionOf", "facetConnectionOf"]) {
      const ids = /["']?([A-Za-z0-9_-]+)["']?/.exec(decoded(url.searchParams.get(key) ?? ""));
      const id = memberIdIn(ids?.[1] ?? null);
      if (id) return id;
    }
    return null;
  }
  function profileRef(username, id) {
    if (username) return { id, username, url: `${LINKEDIN}/in/${username}/` };
    return id ? { id, username: null, url: `${LINKEDIN}/in/${id}/` } : null;
  }
  function profileKey(profile) {
    return profile.username ? `user:${profile.username.toLowerCase()}` : `id:${profile.id ?? ""}`;
  }
  function profilePageOf(url) {
    const [first, second] = pathParts(url);
    if (first?.toLowerCase() !== "in" || !second) return null;
    const part = decoded(second);
    if (MEMBER_ID.test(part)) return profileRef(null, part);
    return profileRef(usernameOf(second), memberIdFrom(url));
  }
  function profileFromUrl(url) {
    return pathParts(url).length === 2 ? profilePageOf(url) : null;
  }
  function threadFromUrl(url) {
    const [first, second, third] = pathParts(url);
    if (first !== "messaging" || second !== "thread" || !third) return null;
    const id = decoded(third);
    if (id === "new" || !THREAD_KEY.test(id)) return null;
    return { id, encrypted: false, url: `${LINKEDIN}/messaging/thread/${id}/` };
  }
  function postFromUrn(urn) {
    const match = urn ? POST_URN.exec(decoded(urn).trim()) : null;
    return match ? `${LINKEDIN}/feed/update/urn:li:${match[1]}:${match[2]}/` : null;
  }
  function postUrlFrom(url) {
    const [first, second, third] = pathParts(url);
    if (first === "feed" && second === "update" && third) return postFromUrn(third);
    if (first === "posts" && second) {
      const match = POST_SLUG.exec(decoded(second));
      return match ? `${LINKEDIN}/feed/update/urn:li:${match[1]}:${match[2]}/` : null;
    }
    return null;
  }
  var fromLink = (read) => (href, base = LINKEDIN) => {
    const url = linkedinUrl(href, base);
    return url ? read(url) : null;
  };
  var profileRefOf = fromLink(profileFromUrl);
  var threadOf = fromLink(threadFromUrl);
  var postOf = fromLink(postUrlFrom);

  // src/hfos/files.ts
  function fileUrlOf(path) {
    const windows = /^[a-z]:[\\/]/i.test(path);
    const parts = path.split(windows ? /[\\/]/ : "/");
    const spelled = parts.map(
      (part, i) => windows && i === 0 ? part.toUpperCase() : encodeURIComponent(part)
    );
    return windows ? `file:///${spelled.join("/")}` : `file://${spelled.join("/")}`;
  }
  function linkedInFileParts(read) {
    let noLink = 0;
    const person = (p) => {
      const profile = p.url ? profileRefOf(p.url) : null;
      if (!profile) {
        noLink++;
        return [];
      }
      return [{ name: p.name, profile, mutualConnections: null, since: p.at }];
    };
    const connections = read.connections.flatMap(person);
    const connected = /* @__PURE__ */ new Set([
      ...connections.map((c) => profileKey(c.profile)),
      ...read.connections.map((c) => `name:${nameKey(c.name)}`)
    ]);
    const waiting = read.invitations.filter((i) => {
      const profile = i.url ? profileRefOf(i.url) : null;
      return !connected.has(profile ? profileKey(profile) : `name:${nameKey(i.name)}`);
    });
    const lists = [
      ["friends", connections],
      ["requests", waiting.filter((i) => i.direction === "received").flatMap(person)],
      ["sent", waiting.filter((i) => i.direction === "sent").flatMap(person)]
    ];
    const parts = [];
    for (const [list, people] of lists)
      for (let at = 0; at < people.length; at += FRIENDS_SAVE_MOST)
        parts.push({ list, people: people.slice(at, at + FRIENDS_SAVE_MOST) });
    const chats = read.chats.map(({ url: _url, ...chat }) => chat);
    for (const part of downloadParts({ people: [], chats }))
      if (part.chats.length) parts.push({ chats: part.chats });
    return {
      parts,
      connections: connections.length,
      invitations: waiting.length,
      chats: chats.length,
      noLink
    };
  }

  // src/offscreen.ts
  var kept = {
    platform: "facebook",
    parts: []
  };
  function open(path) {
    return new Promise((done, failed) => {
      const request = new XMLHttpRequest();
      request.open("GET", fileUrlOf(path));
      request.responseType = "blob";
      request.onload = () => request.response instanceof Blob && request.response.size > 0 ? done(request.response) : failed(new Error("empty"));
      request.onerror = () => failed(new Error("unreadable"));
      request.send();
    });
  }
  async function readLinkedIn(blobs) {
    const read = await readLinkedInExport(blobs);
    const got = linkedInFileParts(read);
    kept = { platform: "linkedin", parts: got.parts };
    return {
      ok: true,
      madeAt: read.madeAt,
      parts: got.parts.length,
      people: got.connections + got.invitations,
      chats: got.chats,
      connections: got.connections,
      invitations: got.invitations,
      noLink: got.noLink
    };
  }
  async function answer(ask) {
    if (ask.type === "hfos-file-part") {
      const lost = { ok: false, error: "The extension lost what it read. Ask again." };
      if (kept.platform === "linkedin") {
        const part2 = kept.parts[ask.i];
        return part2 ? { ok: true, filePart: part2 } : lost;
      }
      const part = kept.parts[ask.i];
      return part ? { ok: true, part } : lost;
    }
    const linkedIn = ask.platform === "linkedin";
    try {
      const blobs = await Promise.all(ask.paths.map(open));
      if (linkedIn) return await readLinkedIn(blobs);
      const read = await readDownload(blobs);
      kept = { platform: "facebook", parts: downloadParts(read) };
      return {
        ok: true,
        madeAt: read.madeAt,
        parts: kept.parts.length,
        people: read.people.length,
        chats: read.chats.length
      };
    } catch (error) {
      return {
        ok: false,
        error: error instanceof DownloadError ? (linkedIn ? LINKEDIN_FILE_PROBLEMS : DOWNLOAD_PROBLEMS)[error.rule] : "Those files couldn’t be opened. Check they’re still in your downloads folder, then ask again."
      };
    }
  }
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.tab) return false;
    if (sender.url && !sender.url.startsWith(chrome.runtime.getURL(""))) return false;
    const ask = message;
    if (ask?.target !== "offscreen") return false;
    void answer(ask).then(respond);
    return true;
  });
})();
